<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Round;
use App\Models\Event;
use App\Models\Team;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Round>
 */
class RoundFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'event_id' => Event::inRandomOrder()->first()->id,
            'hour' => $this->faker->time,
        ];
    }
    public function configure(): Factory
    {
        return $this->afterCreating(function (Round $round) {
            // Sélectionner deux équipes existantes au hasard
            $teams = Team::inRandomOrder()->limit(2)->get();
            $round->teams()->attach($teams);
        });
    }
}
