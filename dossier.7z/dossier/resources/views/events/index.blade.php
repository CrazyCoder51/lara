@extends('events.template')
@section('content')

<div class="container mt-5">
    <h2 class="mt-4">Liste des épreuves</h2>
    <input type="text" id="searchInput" class="form-control mb-3" placeholder="Rechercher par nom d'événement">
    @foreach ($events as $event)
        <div class="card mb-4">
            <div class="card-header" style="position: relative; overflow: hidden;">
                <div class="img-background-event" style="background-image: url('{{ asset('storage/images/logo.png') }}');">
                </div>
                <h2 class="card-title" style="margin-bottom: 0px; position: relative; z-index: 1;">
                    <a href="{{ route('events.show', ['event' => $event->id]) }}">
                        <i class="fa-solid fa-calendar-days" style="color: #000000;"></i><i class="fa-duotone fa-swords"></i> {{$event->name}}
                    </a>
                </h2>
            </div>
            
            <div class="card-body">
                <ul class="list-unstyled">
                    <li class="mb-2"><strong>Date:</strong> {{ \Carbon\Carbon::parse($event->date)->locale('fr_FR')->isoFormat('dddd D MMMM') }}</li>
                    <li class="mb-2"><strong>Épreuve de :</strong> {{ $event->sport }}</li>
                    <li>
                        <ul class="list-group">
                            <li class="list-group-item p-0"><div class="d-flex align-items-center justify-content-center p-1"><strong>Liste des manches</strong></div></li>
                            @forelse ($event->rounds()->orderBy('hour')->get() as $round)
                                @if ($round->teams->isNotEmpty())
                                    <li class="list-group-item p-0">
                                        <a href="{{ route('rounds.show', ['round' => $round->id]) }}" class="d-block w-100 p-3">
                                            <div class="d-flex align-items-center justify-content-center">
                                                <p class="mb-0 text-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                                    @foreach ($round->teams as $team)
                                                        @php
                                                            $teamResult = $round->results()->where('team_id', $team->id)->first();
                                                            $teamScore = $teamResult ? $teamResult->score : null;
                                                            $maxScore = $round->results()->max('score');
                                                        @endphp
                        
                                                        <span class="{{ $teamScore !== null && $teamScore == $maxScore ? 'text-success' : '' }}">
                                                            {{ $team->name }}
                        
                                                            @if ($teamResult)
                                                                <span class="font-weight-bold">({{ $teamResult->score }})</span>
                                                            @endif
                                                        </span>
                        
                                                        @if (!$loop->last) <span class="font-weight-bold">VS</span> @endif
                                                    @endforeach
                                                    <small>({{ \Carbon\Carbon::parse($round->hour)->isoFormat('H[h]mm') }})</small>
                                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                @else
                                    <li class="list-group-item p-0">
                                        <a href="{{ route('rounds.show', ['round' => $round->id]) }}" class="d-block w-100 p-3">
                                            <div class="d-flex align-items-center justify-content-center">
                                                <p class="mb-0 text-center">
                                                    Manche vide
                                                    <small>({{ \Carbon\Carbon::parse($round->hour)->isoFormat('H[h]mm') }})</small>
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                @endif
                            @empty
                            <li class="list-group-item p-0"><div class="d-flex align-items-center justify-content-center p-1">--- Aucune manche ---</div></li>
                            @endforelse
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    @endforeach
</div>
<script>
    //A FAIRE : utiliser du ajax a la place, meme script que pour equipe
    $(document).ready(function() {
        $('#searchInput').on('input', function() {
            var searchText = $(this).val().toLowerCase();
            
            $('.card').each(function() {
                var eventName = $(this).find('.card-title a').text().toLowerCase();
                
                if (eventName.includes(searchText)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    });
</script>


@endsection