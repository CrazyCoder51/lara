@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Modifier une épreuve : Modifier une manche</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin.events.edit', ['id' => $round->event->id])}}">🠔 Retour</a>

        <div class="card mb-4" style="background-color: #C4C4C4;">
            <div class="card-body">
                <h2>Manche <small>#{{ $round->id }}</small></h2>
                <p><strong>Manche appartenant à : </strong>{{$round->event->name}}</p>
                <p><strong>Heure : </strong>{{ $round->hour }}</p>
                
                <hr>

                <h3>Modifier l'heure de la manche</h3>

                <form action="{{ route('admin.events.rounds.update', ['id' => $round->id]) }}" method="post">
                    @csrf
                    <label for="hour">Modifier l'heure de la manche</label>
                    <input type="time" name="hour" class="form-control" required>

                    <button type="submit" class="btn btn-primary mt-2">Modifier l'heure</button>
                </form>

                <hr>

                <h3>Ajouter une equipe à la manche</h3>

                <form action="{{ route('admin.events.rounds.addTeam', ['id' => $round->id]) }}" method="post">
                    @csrf
                
                    <div class="form-group">
                        <label for="team_id">Sélectionnez une équipe :</label>
                        <select name="team_id" class="form-control" required>
                            @foreach ($teams as $team)
                                <option value="{{ $team->id }}">{{ $team->name }}</option>
                            @endforeach
                        </select>
                    </div>
                
                    <button type="submit" class="btn btn-success">Ajouter à la manche</button>
                </form>
            </div>
        </div>

        <h3>Équipes de la manche</h3>

        @if ($round->teams->isNotEmpty())
            <table class="table mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom de l'équipe</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($round->teams as $team)
                        <tr>
                            <td>{{ $team->id }}</td>
                            <td>{{ $team->name }}</td>
                            <td>
                                <form action="{{ route('admin.events.rounds.removeTeam', ['roundId' => $round->id, 'teamId' => $team->id]) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette équipe de la manche ?')">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <p>Aucune équipe dans cette manche.</p>
        @endif
    </div>
@endsection