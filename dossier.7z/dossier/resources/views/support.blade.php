@extends('template')
@section('title') Jeux de l'URCA - Support @endsection
@section('AdditionalHead')
<script defer src="{{asset('storage/js/contact.js')}}"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
@endsection
@section('curseur-header')
    @php
        $curseur = 6;
    @endphp
@endsection
@section('content')
<div class="container mt-5">
<h2 class="mt-4">Nous contacter</h2>
<div class="card">
  <div class="card-header">
        <br>
        <form onsubmit="return false">
          <label class="contact-label" for="lastName">Nom</label>
          <input class="contact-input" type="text" placeholder="Entrez votre nom" id="lastName">
          <br><br>
          <label class="contact-label" for="firstName">Prénom</label>
          <input class="contact-input" type="text" placeholder="Entrez votre prénom" id="firstName">
          <br><br>
          <label class="contact-label" for="email">E-mail</label>
          <input class="contact-input" type="email" placeholder="Entrez votre e-mail" id="email">
          <br><br>
          <label class="contact-label" for="country">Pays</label>
          <select class="contact-select" id="country" >
            <option disabled selected value> -- Sélectionnez votre pays-- </option>
            <option value="Memento">Memento</option>
            <option value="Gotham city">Gotham city</option>
            <option value="Shrekin Time">Kingdom of Far Far Away</option>
            <option value="Robert Deniro">La La Land directed by Martin Scorcese</option>
            <option value="Latveria">Latveria</option>
            <option value="Shiganshina">Shiganshina</option>
            <option value="Top Gun Maverick">Top Gun Maverick</option>
          </select>
          <br><br>
          <label class="contact-label" for="question">Quelle est votre question ?</label>
          <textarea name="blog" id="question" class="contact-textarea"></textarea>
          <br><br> 
          <div class="contact-button-mail-div">  
            <a onclick="Msg()" id="link" class="contact-button-mail">Envoyer l'e-mail</a>
          </div> 
          <br> 
        </form>
      </div>
    </div>
</div>

@endsection