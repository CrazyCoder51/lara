@extends('template')
@section('title') Jeux de l'URCA - Épreuves @endsection
@section('curseur-header')
    @php
        $curseur = 4;
    @endphp
@endsection
@section('content')
@yield('content')
@endsection