@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Modifier une épreuve</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin.events')}}">🠔 Retour</a>

        <div class="card mb-4" style="background-color: #C4C4C4;">
            <div class="card-body">
                <h2>{{ $event->name }}<small>#{{ $event->id }}</small></h2>
                <p><strong>Date : </strong>{{ $event->date }}</p>
                
                <hr>

                <h3>Modifier l'épreuve</h3>

                <form action="{{ route('admin.events.update', ['id' => $event->id]) }}" method="post">
                    @csrf
                    <label for="name">Modifier le nom de l'épreuve</label>
                    <input type="text" name="name" class="form-control">

                    <label for="date">Modifier la date</label>
                    <input type="date" name="date" class="form-control">

                    <label for="sport">Modifier le sport de l'épreuve</label>
                    <input type="text" name="sport" class="form-control">

                    <button type="submit" class="btn btn-primary mt-2">Modifier l'épreuve</button>
                </form>

                <hr>

                <h3>Ajouter une manche</h3>

                <form action="{{ route('admin.events.rounds.create') }}" method="post">
                    @csrf
                    <input type="hidden" name="event_id" value="{{ $event->id }}">
                    <label for="hour">Heure de la nouvelle manche :</label>
                    <input type="time" name="hour" class="form-control" required>
                    <button type="submit" class="btn btn-primary mt-2">Créer une nouvelle manche</button>
                </form>

            </div>
        </div>

        <h3>Liste des manches</h3>

        @if ($event->rounds->isNotEmpty())
            <table class="table mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Heure de la manche</th>
                        <th>Nombre d'équipes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($event->rounds as $round)
                        <tr>
                            <td>{{ $round->id }}</td>
                            <td>{{ $round->hour }}</td>
                            <td>{{ $round->teams->count() }}</td>
                            <td>
                                <a href="{{ route('admin.events.rounds.edit', ['id' => $round->id]) }}" class="btn btn-primary">Modifier</a>

                                <form action="{{ route('admin.events.rounds.delete', ['id' => $round->id]) }}" method="post" style="display: inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette manche ?')">Supprimer</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @else
            <p>Aucune manche pour cette épreuve.</p>
        @endif
    </div>
@endsection