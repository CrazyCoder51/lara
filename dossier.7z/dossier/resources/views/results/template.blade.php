@extends('template')
@section('title') Jeux de l'URCA - Resultat @endsection
@section('curseur-header')
    @php
        $curseur = 4;
    @endphp
@endsection
@section('content')
@yield('content')
@endsection