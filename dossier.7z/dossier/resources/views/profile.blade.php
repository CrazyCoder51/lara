@extends('template')
@section('title') Jeux de l'URCA - Profile @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h4>Profile</h4>
            <div class="card">
                <div class="card-header bg-light text-dark"><strong><h2 class="mb-0">{{ $user->name }}</h2></strong></div>
                <div class="card-body">
                    <div class="text-center">
                        <img class="img-fluid rounded-circle mb-3" src="{{ asset('storage/avatars/' . $user->avatar) }}" alt="Photo de profil" width="150">
                    </div>

                    <h4>Fait parti de l'équipe</h4>
                    @if($user->team)
                        <ul class="list-group">
                            <li class=" p-0 list-group-item">
                                <a href="{{ route('teams.show', ['team' => $user->team->id]) }}" class="d-block w-100 p-3">
                                    <div class="d-flex align-items-center">
                                        @if($user->team->logo)
                                            <img class="img-fluid rounded-circle mr-3" style="max-width: 50px;" src="{{ asset('storage/teams/' . $user->team->logo) }}" alt="Logo de l'équipe" style="max-width: 200px; max-height: 100px;">
                                        @else
                                            <img class="img-fluid rounded-circle mr-3" style="max-width: 50px;" src="{{ asset('storage/teams/default.png') }}" alt="Logo de l'équipe" style="max-width: 200px; max-height: 100px;">
                                        @endif
                                        <h5 class="mb-0">{{$user->team->name}}</h5>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    @else
                        <li class=" p-0 list-group-item">
                            <div class="d-flex align-items-center d-block w-100 p-3">
                                <h5 class="mb-0">Ce joueur n'appartient à aucune équipe.</h5>
                            </div>
                        </li>
                    @endif

                </div>
            </div>
        </div>
    </div>
</div>
@endsection