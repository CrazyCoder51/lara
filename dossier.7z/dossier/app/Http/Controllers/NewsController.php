<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

use Illuminate\Http\Request;
use App\Models\News;
use Illuminate\Support\Facades\DB;

class NewsController extends Controller
{
    public function index()
    {
        $news = News::latest()->get();
        return view('news.index', compact('news'));
    }

    public function indexAdmin()
    {
        $news = News::all();
        return view('admin.news', compact('news'));
    }

    public function create()
    {
        return view('news.create');
    }
    public function store(Request $request)
    {
        try{
            $request->validate([
                'title' => 'required',
                'content' => 'required',
            ]);
        
            $news = new News;
            $news->title = $request->input('title');
            $news->content = $request->input('content');
            if ($request->hasFile('image')) {
                $request->validate([
                    'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
                ]);
                $file = $request->file('image');
                $fileName = Str::random(30) . '.' . $file->getClientOriginalExtension(); //nom de fichier aleatoire

                $filePath = public_path('storage/news/' . $fileName);

                // stock fichier avec le nom aleatoire
                Image::make($file)->fit(1000, 500)->save($filePath);

                $news->image = $fileName;
            }
        
            $news->save();

            return redirect()->route('admin.news')->with('success', 'Actualité créée avec succès');
        } catch (\Exception $e) {
            return redirect()->route('admin.news')->with('error', 'Erreur : '.$e);
        }
    }

    public function show($id)
    {
        $news = News::find($id);

        $latestNews = News::latest()->take(6)->get();

        return view('news.show', compact('news', 'latestNews'));
    }

    public function edit($id)
    {
        $news = News::find($id);
        return view('admin.news.edit', compact('news'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'content' => 'required',
        ]);

        $news = News::find($id);
        $news->title = $request->input('title');
        $news->content = $request->input('content');

        if ($request->hasFile('image')) {
            $request->validate([
                'image' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            ]);
            $file = $request->file('image');
            $fileName = Str::random(30) . '.' . $file->getClientOriginalExtension(); //nom de fichier aleatoir

            $filePath = public_path('storage/news/' . $fileName);

            // stock fichier avec le nom aleatoire
            Image::make($file)->fit(1000, 500)->save($filePath);

            $news->image = $fileName;
        }
        $news->save();

        return redirect()->route('admin.news')->with('success', 'Actualité modifiée avec succès');
    }

    public function destroy($id)
    {
        $news = News::find($id);
        $news->delete();

        return redirect()->route('admin.news')->with('success', 'Actualité supprimée avec succès');
    }
}
