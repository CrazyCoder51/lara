@extends('template')
@section('title') Jeux de l'URCA - Mon compte @endsection
@section('curseur-header')
    @php
        $curseur = "account";
    @endphp
@endsection
@section('content')
@auth

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @error('avatar')
                    <div class="alert alert-danger" role="alert">
                        {{ $message }}
                    </div>
                @enderror
                @if(session('success'))
                    <div class="alert alert-success" role="alert">
                        {{ session('success') }}
                    </div>
                @endif
                <a class="text-secondary mb-4" href="{{route('index')}}">🠔 Accueil</a>
                <div class="card">
                    <div class="card-header bg-light text-dark"><strong>Mon compte : </strong>{{ Auth::user()->name }}</div>
                    <div class="card-body">
                        <div class="text-center">
                            <img id="profileImage" class="img-fluid rounded-circle mb-3" src="{{ asset('storage/avatars/' . Auth::user()->avatar) }}" alt="Photo de profil" width="150">
                            <p>{{ Auth::user()->email }}</p>
                        </div>

                        <hr>

                        <form method="POST" action="{{ route('profile.updatePhoto') }}" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                                <label for="avatar">Changer la Photo de Profil</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input @error('avatar') is-invalid @enderror" id="avatar" name="avatar">
                                    <label class="custom-file-label" for="avatar">Choisir un fichier</label>
                                    @error('avatar')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>
                            

                            <button type="submit" class="btn btn-primary btn-block text-center">Mettre à jour</button>
                        </form>

                        <hr>
                        <div class="text-center">
                            <a href="{{ route('profile.show', ['user' => Auth::user()]) }}" class="btn btn-primary btn-block text-center" style="background-color: #717171; border-color: #717171; color: white;">Voir mon profil</a>
                        </div>
                        <br>
                        <div class="text-center">
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="btn btn-block btn-danger">Se déconnecter</button>
                            </form>
                        </div>
                        @role('organizer')
                            <bouton>
                            <br>
                            <div class="text-center">
                                <a href="{{route('admin')}}" class="btn btn-info btn-block text-center" style="color:white;">Panneau de configuration ADMIN</a>
                            </div>
                        @endrole
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function updateProfileImage(input) {
            var reader = new FileReader();
    
            reader.onload = function (e) {
                var img = new Image();
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    var ctx = canvas.getContext('2d');
                    var canvasSize = 200;
                    var cutSize = Math.min(img.width, img.height);
                    canvas.width = canvasSize;
                    canvas.height = canvasSize;
                    var offsetX = (img.width - cutSize) / 2;
                    var offsetY = (img.height - cutSize) / 2;
                    ctx.drawImage(img, offsetX, offsetY, cutSize, cutSize, 0, 0, canvasSize, canvasSize);
                    document.getElementById('profileImage').src = canvas.toDataURL('image/png');
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
        document.getElementById('avatar').addEventListener('change', function () {
            var fileName = this.files[0].name;
            var label = document.querySelector('.custom-file-label');
            label.textContent = fileName;
            updateProfileImage(this);
        });
    </script>
    
    
    
@endauth
@endsection