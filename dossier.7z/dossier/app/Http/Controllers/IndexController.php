<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\News;
use App\Models\Medal;
use App\Models\Event;
use App\Models\Result;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index(){
        // RETOURNE LE PROCHAIN EVENT
        $nextEvent = Event::where('date', '>', Carbon::now())->orderBy('date', 'asc')->first();
        //RETOURNE LES 3 DER NEWS
        $news = News::latest()->take(6)->get();
        
        $events = Event::all();

        $firstEvent = NULL;
        $lastEvent = NULL;

        if ($events->isNotEmpty()) {
            $firstEvent = Event::orderBy('date', 'asc')->first()->date;
            $lastEvent = Carbon::parse(Event::orderBy('date', 'desc')->first()->date)->addDay();
        }

        $medalStandings = Medal::selectRaw('team_id, 
                                SUM(CASE WHEN type = "gold" THEN 3 WHEN type = "silver" THEN 2 WHEN type = "bronze" THEN 1 ELSE 0 END) as total_points,
                                SUM(type = "gold") as gold_count,
                                SUM(type = "silver") as silver_count,
                                SUM(type = "bronze") as bronze_count')
            ->groupBy('team_id')
            ->orderByDesc('total_points')
            ->get();

        $recentEvents = Event::where('date', '<', now())
            ->orderByDesc('date')
            ->take(3)
            ->get();
    
        $eventData = [];
    
        // Recupere total points des equipe par epreuve
        foreach ($recentEvents as $event) {
            $teamPoints = Result::with('team')
                ->whereHas('round', function ($query) use ($event) {
                    $query->where('event_id', $event->id);
                })
                ->groupBy('team_id')
                ->select('team_id', DB::raw('SUM(points) as total_points'))
                ->orderByDesc('total_points')
                ->first();
    
            // épreuve + points equipe avec le plus de points
            $eventData[] = [
                'event' => $event,
                'topTeam' => $teamPoints,
            ];
        }

        return view('index', compact('news', 'nextEvent','events','firstEvent','lastEvent','medalStandings','eventData'));
    }
}
