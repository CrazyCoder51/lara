@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Résultats</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin')}}">🠔 Retour</a>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Ajouter résultat</h3>
                <form method="POST" action="{{ route('admin.results.create') }}">
                    @csrf
        
                    <div class="form-group">
                        <label for="event_id">Sélectionner l'épreuve</label>
                        <select name="event_id" id="event_id" class="form-control" required>
                            @foreach ($events as $event)
                                <option value="{{ $event->id }}">{{ $event->name }}</option>
                            @endforeach
                        </select>
                    </div>
        
                    <div class="form-group">
                        <label for="round_id">Sélectionner la manche</label>
                        <select name="round_id" id="round_id" class="form-control" required>
                        </select>
                    </div>
        
                    <div class="form-group">
                        <label for="team_id">Sélectionner l'équipe</label>
                        <select name="team_id" id="team_id" class="form-control" required>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="score">Score</label>
                        <input type="text" name="score" id="score" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="points">Points</label>
                        <input type="text" name="points" id="points" class="form-control" required>
                    </div>
        
                    <button type="submit" class="btn btn-primary">Ajouter résultat manche épreuve</button>
                </form>
            </div>
        </div>
        
        @if ($results->count() > 0)
            <div class="table-responsive mt-4">
                <h3>Liste des résultats</h3>
                @foreach ($events as $event)
                    @if ($event->rounds->isNotEmpty() && $event->rounds->first()->results->isNotEmpty())
                        <hr>
                        <h4>Epreuve : {{$event->name}}</h4>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Team</th>
                                    <th>Manche (id)</th>
                                    <th>Score</th>
                                    <th>Points</th>
                                    <th>Supprimer</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($event->rounds as $round)
                                    @foreach ($round->results as $result)
                                        <tr>
                                            <td>{{ $result->id }}</td>
                                            <td>{{ $result->team->name }}#{{ $result->team_id }}</td>
                                            <td>{{ $result->round_id }}</td>
                                            <td>{{ $result->score }}</td>
                                            <td>{{ $result->points }}</td>
                                            <td>
                                                <form action="{{ route('admin.results.delete', ['id' => $result->id]) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce resultat ?')">Supprimer</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                @endforeach
            </div>
        @endif

        <script>
            $(document).ready(function () {
                var eventSelector = $('#event_id');
                var roundSelector = $('#round_id');
                var teamSelector = $('#team_id');
        
                function populateRounds() {
                    var selectedEventId = eventSelector.val();

                    // AJAX qui recupr les round et les team
                    $.get("{{route('admin.results.getRounds.url')}}" + '/' + selectedEventId, function (data) {
                        roundSelector.empty();

                        // populations des options selon la reponse
                        $.each(data, function (index, round) {
                            var teamsNames = round.teams.map(function (team) {
                                return team.name;
                            }).join(' VS ');

                            roundSelector.append('<option value="' + round.id + '">' + round.id + ' ' + teamsNames + '</option>');
                        });
                        roundSelector.change();
                    });
                }
        
                function populateTeams() {
                    var selectedRoundId = roundSelector.val();
        
                    // AJAX qui recupr les team
                    $.get("{{route('admin.results.getTeams.url')}}" + '/' +  selectedRoundId, function (data) {
                        teamSelector.empty(); // Clear existing options
        
                        // populations des options selon la reponse
                        $.each(data, function (index, team) {
                            teamSelector.append('<option value="' + team.id + '">' + team.name + '</option>');
                        });
                    });
                }
        
                eventSelector.change(populateRounds);
                roundSelector.change(populateTeams);
                populateRounds();
            });
        </script>
    </div>
@endsection
