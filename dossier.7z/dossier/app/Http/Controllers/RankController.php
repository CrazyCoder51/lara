<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Result;
use App\Models\Medal;

use Illuminate\Support\Facades\DB;

class RankController extends Controller
{
    public function index()
    {
        $teams = Result::select('team_id', DB::raw('SUM(points) as total_points'))
            ->groupBy('team_id')
            ->orderByDesc('total_points')
            ->get();

        // Load team details
        $teams->load('team');

        // classement des medaille -> un score de medaille est calculé gold = 3, silver = 2, bronze = 1. On fais l'addition est on a le trie
        $medalStandings = Medal::selectRaw('team_id, 
                                SUM(CASE WHEN type = "gold" THEN 3 WHEN type = "silver" THEN 2 WHEN type = "bronze" THEN 1 ELSE 0 END) as total_points,
                                SUM(type = "gold") as gold_count,
                                SUM(type = "silver") as silver_count,
                                SUM(type = "bronze") as bronze_count')
            ->groupBy('team_id')
            ->orderByDesc('total_points')
            ->get();


        return view('rank.index', compact('teams', 'medalStandings'));
    }
}