<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;

use Illuminate\Http\Request;
use App\Models\Result;
use App\Models\Event;
use App\Models\Team;
use App\Models\Round;


class ResultController extends Controller
{
    public function index()
    {
        $events = Event::all();
        return view('results.index', compact('events'));    
    }

    public function indexAdmin()
    {
        $results = Result::all();
        $events = Event::all();
        $teams = Team::all();

        return view('admin.results', compact('events','teams','results'));
    }

    public function create()
    {
        return view('result.create');
    }

    public function store(Request $request)
    {
        try {
            $round = Round::findOrFail($request->input('round_id'));

            $team = Team::findOrFail($request->input('team_id'));

            $result = Result::create([
                'round_id' => $round->id,
                'team_id' => $team->id,
                'score' => $request->input('score'),
                'points' => $request->input('points'),
            ]);

            return redirect()->back()->with('success', 'Résultat créé avec succès');
        } catch (ModelNotFoundException $e) {
            return redirect()->back()->with('error', 'Erreur : La manche ou l\'équipe spécifiée n\'existe pas.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Erreur une erreur est survenue');
        }
    }

    public function show($id)
    {
        $result = Result::find($id);
        return view('result.show', compact('results'));
    }

    public function edit($id)
    {
        $news = News::find($id);
        return view('admin.result.edit', compact('results'));
    }


    public function update(Request $request, $id)
    {
        $request->validate([
            'score' => 'required',
        ]);

        $results = Results::find($id);
        $results->score = $request->input('score');
        $results->save();

        return redirect()->back()->with('success', 'Resultat modifié avec succès');
    }

    public function destroy($id)
    {
        $results = Result::find($id);
        $results->delete();

        return redirect()->back()->with('success', 'Resultat supprimée avec succès');
    }
    public function getRounds($eventId)
    {
        $rounds = Round::where('event_id', $eventId)->with('teams')->get();

        return response()->json($rounds);
    }
    public function getTeams(Request $request, $roundId)
    {
        $round = Round::with('teams')->findOrFail($roundId);
        $teams = $round->teams;

        return response()->json($teams);
    }
}
