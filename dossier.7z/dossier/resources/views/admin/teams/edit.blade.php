@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Modifier une équipe</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin.teams')}}">🠔 Retour</a>

        <div class="card mb-4" style="background-color: #C4C4C4;">
            <div class="card-body">
                <h2>{{ $team->name }}<small>#{{ $team->id }}</small></h2>
                
                <hr>

                <h3>Modifier l'équipe</h3>
                <form action="{{ route('admin.teams.update', ['team' => $team->id]) }}" method="post">
                    @csrf
                    <label for="name">Modifier le nom de l'équipe</label>
                    <input value="{{$team->name}}" type="text" name="name" class="form-control" required>

                    <label for="composante">Modifier la composante de l'équipe</label>
                    <input value="{{$team->composante}}" type="text" name="composante" class="form-control" required>

                    <button type="submit" class="btn btn-primary mt-2">Modifier l'équipe</button>
                </form>
        
                <hr>

                <h3>Ajouter une utilisateur</h3>

                <form action="{{ route('admin.teams.add-user') }}" method="post">
                    @csrf
                    <input type="hidden" name="team_id" value="{{ $team->id }}">
                    <label for="user">Utilisateur :</label>
                    <select class="form-control" name="user_id" id="user_id">
                        @foreach ($users as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                    <button type="submit" class="btn btn-primary mt-2">Ajouter</button>
                </form>

                <hr>

                <h3>Supprimer l'image</h3>
                @if (!empty($team->logo))
                    <img src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }}" class="img-fluid mb-3">
                @else
                    <img src="{{ asset('storage/teams/default.png') }}" alt="Image par défaut" class="img-fluid mb-3">
                @endif
                <form method="post" action="{{ route('admin.teams.remove-Logo', ['team' => $team->id]) }}">
                    @csrf
                    @method('POST')
                
                    <button type="submit" class="btn btn-danger mt-2 btn-block">Supprimer le logo</button>
                </form>
            </div>
        </div>
        

        @if (!($team->users->isEmpty()))
            <div class="mt-4">
                <h4>{{ $team->name }}</h4>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nom de l'utilisateur</th>
                            <th>Email de l'utilisateur</th>
                            <th>Supprimer de l'équipe</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($team->users as $user)
                            <tr>
                                <td>
                                    <a href="{{ route('profile.show', ['user' => $user->id]) }}">
                                        {{ $user->name }}<small>#{{ $user->id }}</small>
                                    </a>
                                </td>
                                <td>{{ $user->email }}</td>
                                <td>
                                    <form method="post" action="{{ route('admin.teams.remove-user') }}">
                                        @csrf
                                        @method('DELETE')
                                        <input type="hidden" name="user_id" id="user_id" value="{{ $user->id }}">
                                        <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
@endsection

