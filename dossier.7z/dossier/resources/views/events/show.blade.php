@extends('events.template')

@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Détails de l'épreuve</h2>
    <a class="text-secondary mb-4" href="{{route('events')}}">🠔 Liste des épreuves</a>

    <div class="card mb-4">
        <div class="card-header" style="position: relative; overflow: hidden;">
            <div class="img-background-event" style="background-image: url('{{ asset('storage/images/logo.png') }}');">
            </div>
            <h2 class="card-title" style="margin-bottom: 0px; position: relative; z-index: 1;">
                <a href="{{ route('events.show', ['event' => $event->id]) }}">
                    <i class="fa-solid fa-calendar-days" style="color: #000000;"></i><i class="fa-duotone fa-swords"></i> {{$event->name}}
                </a>
            </h2>
        </div>
        <div class="card-body">
            <strong>Date:</strong> {{ \Carbon\Carbon::parse($event->date)->locale('fr_FR')->isoFormat('dddd D MMMM') }}<br>
            <strong>Épreuve de :</strong> {{ $event->sport }}<br>
            <ul class="list-group">
                <li class="list-group-item p-0"><div class="d-flex align-items-center justify-content-center p-1"><strong>Liste des manches</strong></div></li>
                @forelse ($event->rounds()->orderBy('hour')->get() as $round)
                    @if ($round->teams->isNotEmpty())
                    <li class="list-group-item p-0">
                        <a href="{{ route('rounds.show', ['round' => $round->id]) }}" class="d-block w-100 p-3">
                            <div class="d-flex align-items-center justify-content-center">
                                <p class="mb-0 text-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                    @foreach ($round->teams as $team)
                                        @php
                                            $teamResult = $round->results()->where('team_id', $team->id)->first();
                                            $teamScore = $teamResult ? $teamResult->score : null;
                                            $maxScore = $round->results()->max('score');
                                        @endphp
        
                                        <span class="{{ $teamScore !== null && $teamScore == $maxScore ? 'text-success' : '' }}">
                                            {{ $team->name }}
        
                                            @if ($teamResult)
                                                <span class="font-weight-bold">({{ $teamResult->score }})</span>
                                            @endif
                                        </span>
        
                                        @if (!$loop->last) <span class="font-weight-bold">VS</span> @endif
                                    @endforeach
                                    <small>({{ \Carbon\Carbon::parse($round->hour)->isoFormat('H[h]mm') }})</small>
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                </p>
                            </div>
                        </a>
                    </li>
                    @else
                        <li class="list-group-item p-0">
                            <a href="{{ route('rounds.show', ['round' => $round->id]) }}" class="d-block w-100 p-3">
                                <div class="d-flex align-items-center justify-content-center">
                                    <p class="mb-0 text-center">
                                        Manche vide
                                        <small>({{ \Carbon\Carbon::parse($round->hour)->isoFormat('H[h]mm') }})</small>
                                    </p>
                                </div>
                            </a>
                        </li>
                    @endif
                @empty
                    <li class="list-group-item p-0"><div class="d-flex align-items-center justify-content-center p-1">--- Aucune manche ---</div></li>
                @endforelse
            </ul>
            <br>

            <h4>Classement des Points de l'épreuve</h4>
            @if ($eventResults->count() > 0)
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Équipe</th>
                            <th>Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($eventResults as $key => $result)
                            <tr>
                                <td>{{ $key + 1 }}</td>
                                <td>
                                    <a href="{{ route('teams.show', ['team' => $result->team->id]) }}">
                                        @if ($result->team->logo)
                                            <img class="rounded-circle" src="{{ asset('storage/teams/' . $result->team->logo) }}" alt="{{ $result->team->name }} Logo" width="25" style="margin-right: 8px;">
                                        @else
                                            <img class="rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                        @endif
                                        {{ $result->team->name }}
                                    </a>
                                </td>
                                <td>{{ $result->total_points }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <h5 class="mb-0 alert alert-info">Aucun résultat disponible pour cette épreuve.</h5>
            @endif

            @if($medals->isNotEmpty())
                <h4>Attibution des médailles</h4>
                @php
                    $gold = $medals->firstWhere('type', 'gold');
                    $silver = $medals->firstWhere('type', 'silver');
                    $bronze = $medals->firstWhere('type', 'bronze');
                @endphp

                <div class="row mt-3">
                    <div class="col-md-4">
                        <a href="{{ $gold ? route('teams.show', ['team' => $gold->team->id]) : '#' }}" class="text-decoration-none">
                            <div class="d-flex flex-column align-items-center">
                                <i class="fas fa-medal fa-3x" style="color: gold;"></i>
                                <p class="mt-2"><strong>{{ $gold ? $gold->team->name : 'X' }}</strong></p>
                            </div>
                        </a>
                    </div>

                    <div class="col-md-4">
                        <a href="{{ $silver ? route('teams.show', ['team' => $silver->team->id]) : '#' }}" class="text-decoration-none">
                            <div class="d-flex flex-column align-items-center">
                                <i class="fas fa-medal fa-3x" style="color: silver;"></i>
                                <p class="mt-2"><strong>{{ $silver ? $silver->team->name : 'X' }}</strong></p>
                            </div>
                        </a>
                    </div>

                    <div class="col-md-4">
                        <a href="{{ $bronze ? route('teams.show', ['team' => $bronze->team->id]) : '#' }}" class="text-decoration-none">
                            <div class="d-flex flex-column align-items-center">
                                <i class="fas fa-medal fa-3x" style="color: #cd7f32;"></i>
                                <p class="mt-2"><strong>{{ $bronze ? $bronze->team->name : 'X' }}</strong></p>
                            </div>
                        </a>
                    </div>
                </div>
            @endif

            <div class="mt-3">
                <h4>Tout les participants de l'épreuve</h4>
                <ul class="list-group">
                    @php $teamFound=false @endphp
                    @foreach ($event->rounds as $round)
                        @if ($round->teams->isNotEmpty())
                            @php $teamFound=1 @endphp
                            @foreach ($round->teams as $team)
                                <li class="list-group-item p-0">
                                    <a href="{{ route('teams.show', ['team' => $team->id]) }}" class="d-block w-100 p-3">
                                        <div class="d-flex align-items-center">
                                            @if ($team->logo)
                                                <img class="rounded-circle" src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }} Logo" width="25" style="margin-right: 8px;">
                                            @else
                                                <img class="rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                            @endif
                                            <h5 class="mb-0">{{$team->name}}</h5>
                                        </div>
                                    </a>
                                </li>
                            @endforeach
                        @endif
                    @endforeach
                    @if(!($teamFound))
                        <li class="list-group-item p-0"><div class="d-block w-100 p-3 d-flex align-items-center"><h5 class="mb-0">Aucun participant à l'épreuve<h5></div></li>
                    @endif
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection