<x-guest-layout>
    <x-authentication-card>
        <x-slot name="logo">
            <x-authentication-card-logo />
        </x-slot>
        <a style="color: #424242;" href="{{route('login')}}">🠔Retour</a>
        <div class="mb-4 text-sm text-gray-600">
            <a href="{{route('support')}}">Contacter nous</a>
        </div>

        @if (session('status'))
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ session('status') }}
            </div>
        @endif

        <x-validation-errors class="mb-4" />

    
    </x-authentication-card>
</x-guest-layout>
