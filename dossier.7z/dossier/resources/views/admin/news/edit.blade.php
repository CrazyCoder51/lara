@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Admin Panel : Modifier une actualité</h2>

    @if(session('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <a class="text-secondary mb-4" href="{{route('admin.news')}}">🠔 Retour</a>

    <div class="card mb-4" style="background-color: #C4C4C4;">
        <div class="card-body">
            <h2>Modifier l'actualité : {{ $news->id }}</h2>

            <form method="POST" action="{{ route('admin.news.update', ['news' => $news->id])  }}" enctype="multipart/form-data">
                @csrf

                <div class="form-group">
                    <label for="title">Titre de l'actualité</label>
                    <input type="text" name="title" id="title" class="form-control" value="{{ $news->title }}"required>
                </div>

                <div class="form-group">
                    <label for="content">Contenu de l'actualité</label>
                    <textarea name="content" id="content" class="form-control" rows="5" required>{{ $news->content }}</textarea>
                </div>

                <div class="form-group">
                    <label for="image">Image de l'actualité</label>
                    @if (!empty($news->image))
                        <img style="width: 100%;height: 100%;object-fit: cover;margin-bottom: 9px;" src="{{ asset('storage/news/' . $news->image) }}" alt="{{ $news->title }}">
                    @else
                        <img style="width: 100%;height: 100%;object-fit: cover;margin-bottom: 9px;" src="{{ asset('storage/news/default.png') }}" alt="Image par défaut">
                    @endif
                    <input type="file" name="image" id="image">
                </div>    

                <button type="submit" class="btn btn-primary">Modifier l'actualité</button>
            </form>
        </div>
    </div>
</div>
@endsection