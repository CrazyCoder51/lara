@extends('rank.template')
@if ($medalStandings->isNotEmpty() && $medalStandings->count() > 0)
    @section('AdditionalHead')
    <link rel="stylesheet" href="{{asset('storage/css/podium.css')}}">
    <script defer src="{{asset('storage/js/podium.js')}}"></script>
    @endsection
@endif
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Classement Général</h2>

        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <div class="card">
            <div class="card-body">

        @if ($medalStandings->isNotEmpty() && $medalStandings->count() > 0)
            <h5 class="card-subtitle mb-2 text-muted">Podium</h5>
            <div class="scoreboard">
                <div class="scoreboard__podiums">
                    @if($medalStandings->count() > 1)
                        <div class="scoreboard__podium js-podium" data-height="200px">
                            <div class="scoreboard__podium-base scoreboard__podium-base--second">
                                <div class="scoreboard__podium-rank">
                                    <a href="{{ route('teams.show', ['team' => $medalStandings[1]->team->id]) }}">
                                        @if ($medalStandings[1]->team->logo)
                                            <img class="rounded-circle img-podium img-podium-second" src="{{ asset('storage/teams/' . $medalStandings[1]->team->logo) }}" alt="{{ $medalStandings[1]->team->name }} Logo" width="110">
                                        @else
                                            <img class="rounded-circle img-podium img-podium-second" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="110">
                                        @endif
                                    </a>
                                </div>
                            </div>
                            <div class="scoreboard__podium-number">
                                <a class="text-podium" href="{{ route('teams.show', ['team' => $medalStandings[1]->team->id]) }}">
                                    {{ $medalStandings[1]->team->name }}
                                </a>
                                <small><span class="js-podium-data"><i class="fas fa-medal" style="color: gold;"></i>{{ $medalStandings[1]->gold_count }}<i class="fas fa-medal" style="color: silver;"></i>{{ $medalStandings[1]->silver_count }}<i class="fas fa-medal" style="color: #cd7f32;"></i>{{ $medalStandings[1]->bronze_count }}</span></small>
                            </div>
                        </div>
                    @endif


                    <div class="scoreboard__podium js-podium" data-height="250px">
                        <div class="scoreboard__podium-base scoreboard__podium-base--first">
                            <div class="scoreboard__podium-rank">
                                <a href="{{ route('teams.show', ['team' => $medalStandings[0]->team->id]) }}">
                                    @if ($medalStandings[0]->team->logo)
                                        <img class="rounded-circle img-podium img-podium-first" src="{{ asset('storage/teams/' . $medalStandings[0]->team->logo) }}" alt="{{ $medalStandings[0]->team->name }} Logo" width="120">
                                    @else
                                        <img class="rounded-circle img-podium img-podium-first" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="120">
                                    @endif
                                </a>
                            </div>
                        </div>
                        <div class="scoreboard__podium-number">
                            <a class="text-podium" href="{{ route('teams.show', ['team' => $medalStandings[0]->team->id]) }}">
                                {{$medalStandings[0]->team->name}}
                            </a>
                            <small><span class="js-podium-data"><i class="fas fa-medal" style="color: gold;"></i>{{ $medalStandings[0]->gold_count }}<i class="fas fa-medal" style="color: silver;"></i>{{ $medalStandings[0]->silver_count }}<i class="fas fa-medal" style="color: #cd7f32;"></i>{{ $medalStandings[0]->bronze_count }}</span></small>
                        </div>
                    </div>

                    @if($medalStandings->count() > 2)
                        <div class="scoreboard__podium js-podium" data-height="150px">
                            <div class="scoreboard__podium-base scoreboard__podium-base--third">
                                <div class="scoreboard__podium-rank">
                                    <a href="{{ route('teams.show', ['team' => $medalStandings[2]->team->id]) }}">
                                        @if ($medalStandings[2]->team->logo)
                                            <img class="rounded-circle img-podium img-podium-third" src="{{ asset('storage/teams/' . $medalStandings[2]->team->logo) }}" alt="{{ $medalStandings[2]->team->name }} Logo" width="100" style="margin-bottom: -26px">
                                        @else
                                            <img class="rounded-circle img-podium img-podium-third" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="100">
                                        @endif
                                    </a>
                                </div>
                            </div>
                            <div class="scoreboard__podium-number">
                                <a class="text-podium" href="{{ route('teams.show', ['team' => $medalStandings[2]->team->id]) }}">
                                    {{$medalStandings[2]->team->name}}
                                </a>
                                <small><span class="js-podium-data"><i class="fas fa-medal" style="color: gold;"></i>{{ $medalStandings[2]->gold_count }}<i class="fas fa-medal" style="color: silver;"></i>{{ $medalStandings[2]->silver_count }}<i class="fas fa-medal" style="color: #cd7f32;"></i>{{ $medalStandings[2]->bronze_count }}</span></small>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            @endif
                <div class="d-flex align-items-center justify-content-between">
                    <h5 class="card-subtitle mb-2 text-muted">Classement des Médailles</h5>
                    <button style="padding-bottom:2px;padding-top:2px;margin-bottom: 6px;margin-top: -9px;width: 145px;" id="toggleTeamComponent" class="btn btn-outline-secondary float-end">Équipe</button>
                </div>
            
                @if ($medalStandings->count() > 0)
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th class="teamNameHeader">Équipe</th>
                                <th class="teamComponentHeader" style="display: none;">Composante</th>
                                <th><i class="fas fa-medal" style="color: gold;"></i> Or</th>
                                <th><i class="fas fa-medal" style="color: silver;"></i> Argent</th>
                                <th><i class="fas fa-medal" style="color: #cd7f32;"></i> Bronze</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($medalStandings as $key => $medalStanding)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>
                                        <a href="{{ route('teams.show', ['team' => $medalStanding->team->id]) }}">
                                            @if ($medalStanding->team->logo)
                                                <img class="teamLogo rounded-circle" src="{{ asset('storage/teams/' . $medalStanding->team->logo) }}" alt="{{ $medalStanding->team->name }} Logo" width="25" style="margin-right: 8px;">
                                            @else
                                                <img class="teamLogo rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                            @endif
                    
                                            {{-- Utilisez une classe spécifique pour le <td> afin de le cibler avec JavaScript --}}
                                            <span class="teamName">{{ $medalStanding->team->name }}</span>
                                            <span class="teamComponent" style="display: none;">{{ $medalStanding->team->composante }}</span>
                                        </a>
                                    </td>
                                    <td>{{ $medalStanding->gold_count }}</td>
                                    <td>{{ $medalStanding->silver_count }}</td>
                                    <td>{{ $medalStanding->bronze_count }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    
                    <script>
                        $(document).ready(function () {
                            //toogle entre composante et equipe
                            $('#toggleTeamComponent').on('click', function () {

                                $('.teamNameHeader, .teamComponentHeader').toggle();
                                $('.teamComponent').toggle();
                                $('.teamLogo').toggle();
                    
                                var buttonText = ($(this).text() === 'Équipe') ? 'Composante' : 'Équipe';
                                $(this).text(buttonText);
                            });
                        });
                    </script>
                                    
                @else
                    <p class="alert alert-info">Aucune médaille disponible.</p>
                @endif
            </div>
        </div>
        <br>
        <div class="card">
            <div class="card-body">
                <h5 class="card-subtitle mb-2 text-muted">Classement actuel</h5>

                @if ($teams->isNotEmpty())
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Équipe</th>
                            <th scope="col">Points</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php $rank = 0; @endphp
                        @foreach ($teams->sortByDesc('total_points') as $team)
                            <tr>
                                <td>{{ ++$rank }}</td>
                                <td>
                                    <a href="{{ route('teams.show', ['team' => $team->team->id]) }}">
                                        @if ($team->team->logo)
                                            <img class="rounded-circle" src="{{ asset('storage/teams/' . $team->team->logo) }}" alt="{{ $team->team->name }} Logo" width="25" style="margin-right: 8px;">
                                        @else
                                            <img class="rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="30">
                                        @endif
                                        {{ $team->team->name }}
                                    </a>
                                </td>
                                <td>{{ $team->total_points }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @else
                    <p class="alert alert-info">Aucune équipe n'a encore participé à une épreuve.</p>
                @endif
            </div>
            
        </div>
    </div>
@endsection