<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Round extends Model {
    use HasFactory;
    
    protected $fillable = ['event_id', 'hour'];

    public function teams() {
        return $this->belongsToMany(Team::class, 'teams_rounds');
    }

    public function results() {
        return $this->hasMany(Result::class);
    }

    public function event() {
        return $this->belongsTo(Event::class);
    }
}