<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckTeam
{
    public function handle($request, Closure $next)
    {
        // Verif si user appartient a une equipe
        if (auth()->check() && (auth()->user()->team_id != NULL)) {
            return $next($request);
        }

        // sinon error de permission
        abort(403, 'Unauthorized action.');
    }
}
