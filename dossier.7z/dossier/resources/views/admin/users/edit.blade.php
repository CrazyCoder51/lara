@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Modifier un utilisateur</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
                @if(session('email') && session('password'))
                    <a href="mailto:{{session('email')}}?subject=Jeux de l'URCA : Votre compte&body=Voici votre mot de passe pour vous connecter sur la plateforme des Jeux de L'URCA : {{session('password')}}%0APour vous connecter, utilisez votre adresse e-mail de l'URCA">Envoyer un mail.</a>
                @endif
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin.users')}}">🠔 Retour</a>

        <div class="card mb-4" style="background-color: #C4C4C4;">
            <div class="card-body">
                <h2>{{ $user->name }}<small>#{{ $user->id }}<small><strong> <a href="{{route('profile.show',['user' => $user->id])}}">(voir le profil)</a></strong></small></small></h2>
                
                <hr>

                <h3>Modifier l'utilisateur</h3>
                <form action="{{ route('admin.users.update', ['user' => $user->id]) }}" method="post">
                    @csrf
                    <label for="name">Modifier le nom l'utilisateur</label>
                    <input value="{{$user->name}}" type="text" name="name" class="form-control" required>

                    <label for="email">Modifier l'email de l'utilisateur</label>
                    <input value="{{$user->email}}" type="email" name="email" class="form-control" required>

                    <button type="submit" class="btn btn-primary mt-2">Modifier l'utilisateur</button>
                </form>
                <hr>

                <h3>Réinitialiser le mot de passe</h3>
                <form method="post" action="{{ route('admin.users.resetPassword', ['user' => $user->id]) }}">
                    @csrf
                    <button type="submit" class="btn btn-warning mt-2 btn-block">Réinitialiser</button>
                </form>
                <hr>

                <h3>Supprimer l'image</h3>
                <img src="{{ asset('storage/avatars/' . $user->avatar) }}" alt="{{ $user->name }}" class="img-fluid mr-3">
                <form method="post" action="{{ route('admin.users.resetImage', ['user' => $user->id]) }}">
                    @csrf
                    <button type="submit" class="btn btn-danger mt-2 btn-block">Supprimer l'mage</button>
                </form>
            </div>
        </div>
@endsection

