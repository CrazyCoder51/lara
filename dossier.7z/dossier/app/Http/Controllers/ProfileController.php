<?php

namespace App\Http\Controllers;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\File;
use DataTables;

class ProfileController extends Controller
{
    public function index()
    {
        $users = User::all();

        return view('admin.users', ['users' => $users]);
    }
    public function indexAccount()
    {
        return view('account');
    }
    public static function store(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email|unique:users',
            ]);
    
            // mot de passe aleatoire
            $password = Str::random(12);
    
            // new user
            $user = User::create([
                'email' => $request->input('email'),
                'name' => $request->input('name'),
                'password' => Hash::make($password),
            ]);
            
            //met le role
            if($request->input('email')){
                $user->assignRole('organizer');
            }
            else{
                $user->assignRole('joueur');
            }
    
            return redirect()->back()->with(['success' =>'L\'utilisateur a bien été créé. Mot de passe : ' . $password . '.', 'email' => $user->email, 'password' => $password]);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur s\'est produite lors de la création de l\'utilisateur.');
        }
    }

    public function resetPassword(User $user)
    {
        try{
            $password = Str::random(12); // mot de passe aleatoire

            $user->update(['password' => Hash::make($password)]);

            return redirect()->back()->with(['success'=> 'Mot de passe : ' . $password . '.', 'email' => $user->email, 'password' => $password]);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur c\'est produite');
        }
    }

    public function resetImage(User $user)
    {
        try{
            $imageName = $user->avatar;

            if($imageName == "default.png"){
                return redirect()->back()->with('error', 'L\'utilisateur n\'a pas d\'avatar personalisé.');
            }

            $user->avatar = "default.png";

            $user->save();

            File::delete(public_path('storage/avatars/' . $imageName));

            return redirect()->back()->with('success', 'L\'avatar a bien été supprimé.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur c\'est produite');
        }
    }

    public function destroy(Request $request)
    {
        $userId = $request->input('user_id');

        $user = User::find($userId);

        if (!$user) {
            return redirect()->back()->with('error', 'Utilisateur non trouvé.');
        }

        $user->delete();

        return redirect()->back()->with('success', 'Utilisateur supprimé avec succès.');
    }
    public function show(User $user)
    {
        return view('profile', ['user' => $user]);
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        try{
            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email,' . $user->id,
            ]);

            if ($validatedData['name'] === $user->name && $validatedData['email'] === $user->email) {
                return redirect()->back()->with('error', 'Aucun changement détecté.');
            }

            $user->update($validatedData);

            return redirect()->back()->with('success', 'Équipe mise à jour avec succès');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenu .' . $e->getMessage());
        }
    }

    public function updatePhoto(Request $request)
    {
        $validatedData = $request->validate([
            'avatar' => 'image|mimes:jpeg,png,jpg,gif|max:2048', 
        ]);

        // user connecté
        $user = auth()->user();

        // DL de la nouvelle img
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $extension = $avatar->getClientOriginalExtension();
            $randomFileName = Str::random(30) . '.' . $extension;
            $avatarPath = public_path('storage/avatars/' . $randomFileName);

            //redimensionnez
            Image::make($avatar)->fit(200, 200)->save($avatarPath);

            // maj dans la bd
            $user->avatar = $randomFileName;
            $user->save();
        }

        return redirect()->back()->with('success', 'Profil mis à jour avec succès.');
    }
    public function getUsersData(Request $request)
    {
        $query = User::query();

        // jointure team pour recup le nom
        $query->leftJoin('teams', 'users.team_id', '=', 'teams.id')
            ->select('users.id', 'users.name', 'users.email', 'users.avatar', 'teams.name as team_name');

        // Filtrage par nom
        if ($request->has('search.value')) {
            $query->where('users.name', 'like', '%' . $request->input('search.value') . '%');
        }

        // Triage par colonne
        if ($request->has('order.0.column') && $request->has('order.0.dir')) {
            $orderColumn = $request->input('order.0.column');
            $orderDirection = $request->input('order.0.dir');
            $query->orderBy($request->input("columns.$orderColumn.data"), $orderDirection);
        }

        // nombre par page
        $perPage = $request->input('length');
        $page = $request->input('start') / $perPage + 1;
        $users = $query->paginate($perPage, ['*'], 'page', $page);
        

        return response()->json([
            'draw' => $request->input('draw'),
            'recordsTotal' => $users->total(),
            'recordsFiltered' => $users->total(),
            'data' => $users->items(),
        ]);
    }
}
