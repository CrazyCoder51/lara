<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Round;
use App\Models\Team;
use Illuminate\Support\Facades\DB;

class RoundController extends Controller
{
    public function show($id)
    {
        $round = Round::find($id);

        // Récupérer les équipes avec la somme des scores pour le round
        $teams = DB::table('teams')
            ->join('results', function ($join) use ($id) {
                $join->on('teams.id', '=', 'results.team_id')
                    ->where('results.round_id', '=', $id);
            })
            ->select('teams.*', DB::raw('SUM(results.score) as total_score'), DB::raw('SUM(results.points) as total_points'))
            ->groupBy('teams.id')
            ->orderByDesc('total_score')
            ->get();

        return view('rounds.show', compact('round', 'teams'));
    }
    public function edit($id)
    {
        $round = Round::findOrFail($id);

        $teams = Team::whereNotIn('id', $round->teams->pluck('id'))->get();

        return view('admin.events.rounds.edit', compact('round', 'teams'));
    }
    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'hour' => 'required|date_format:H:i',
            ]);

            $round = Round::findOrFail($id);

            $round->update([
                'hour' => $request->input('hour'),
            ]);

            return redirect()->back()->with('success', 'Heure de la manche mise à jour avec succès.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenue : ');
        }
    }
    public function store(Request $request)
    {
        $request->validate([
            'event_id' => 'required|exists:events,id',
            'hour' => 'required|date_format:H:i',
        ]);

        Round::create($request->all());

        return redirect()->back()->with('success', 'Manche créée avec succès.');
    }

    public function addTeam(Request $request, $roundId)
    {
        try {
            $round = Round::findOrFail($roundId);

            $request->validate([
                'team_id' => 'required|exists:teams,id',
            ]);

            // Vérifier si équipe est deja dans la manche
            if ($round->teams->contains($request->input('team_id'))) {
                return redirect()->back()->with('error', 'L\'équipe est déjà présente dans la manche.');
            }

            $round->teams()->attach($request->input('team_id'));

            return redirect()->back()->with('success', 'Équipe ajoutée avec succès à la manche.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenue : ');
        }
    }

    public function removeTeam($roundId, $teamId)
    {
        try {
            $round = Round::findOrFail($roundId);

            // detache equipe de la manche
            $round->teams()->detach($teamId);

            return redirect()->back()->with('success', 'Équipe supprimée avec succès de la manche.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenue : ');
        }
    }

    public function destroy($roundId)
    {
        try {
            $round = Round::findOrFail($roundId);

             // detache equipe de la manche
            $round->teams()->detach();

            // + supprime  manche
            $round->delete();

            return redirect()->back()->with('success', 'Manche supprimée avec succès.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenue : ');
        }
    }
}
