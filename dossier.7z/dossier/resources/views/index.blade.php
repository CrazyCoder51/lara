@extends('template')
@section('title') Jeux de l'URCA - Accueil @endsection

@section('curseur-header')
    @php
        $curseur = 1;
    @endphp
@endsection
@section('content')
  <div class="container mt-5">
    <br>
    <div class="card">
      <div class="card-header">
      <h1 class="titre-principal"><strong>Les Jeux de l'URCA</strong></h1>
      </div>
    </div>
    <br>
      <div class="card">
        <div class="card-body">
          <h2><a href="{{route('news')}}">Dernières Actualités</a></h2>
            @if (!empty($news[0]))
              @section('AdditionalHead')
                <script defer src="{{asset('storage/js/main.js')}}"> </script>
              @endsection
              <div class="slideshow-container">
              @foreach ($news as $newsItem)
                <div class="mySlides fadeSlides">
                  <a href="news/{{ $newsItem->id }}">
                    @if (!empty($newsItem->image))
                      <img style="object-fit: cover;width: 100%;border-radius: 4px;" src="{{ asset('storage/news/' . $newsItem->image) }}" alt="{{ $newsItem->title }}">
                    @else
                      <img style="object-fit: cover;width: 100%;border-radius: 4px;" src="{{ asset('storage/news/default.png') }}" alt="{{ $newsItem->title }}">
                    @endif
                    <div style="border-radius: 0px 0px 4px 4px;" class="text">{{$newsItem->title}}</div>
                  </a>
                </div>
                
              @endforeach
              <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
              <a class="suiv" onclick="plusSlides(1)">&#10095;</a>
              <div style="text-align:center">
                <?php $i=1;?>
                @foreach ($news as $newsItem)
                  <span class="dot" onclick="currentSlide({{$i}})"></span> 
                  <?php $i=$i+1;?>
                @endforeach
              </div>
            </div>
            @else
                <div class="card">
                  <div class="card-body">
                    <p class="m-0">Aucune actualité à afficher.</p>
                  </div>
                </div>
            @endif
            <br>

          <div class="card">
            <div class="card-body">
              <h5 class="card-subtitle mb-2 text-muted">Prochaine épreuve</h5>
              @if ($nextEvent)
                <strong><a href="{{route('events.show',['event'=> $nextEvent->id ])}}">{{ $nextEvent->name }} le {{ \Carbon\Carbon::parse($nextEvent->date)->locale('fr_FR')->isoFormat('dddd D MMMM') }}</a></strong>
              @else
                  <strong>Aucune épreuve à venir pour le moment.</strong>
              @endif
            </div>
          </div>
        </div>
      </div>

    <br>

    <div class="card">
      <div class="card-body">
        <h5 class="card-subtitle mb-2 text-muted">Dernières épreuves et meilleures équipes</h5>
        @forelse ($eventData as $data)
          <div class="card">
            <a href="{{route('events.show',['event'=> $data['event']->id ])}}">
              <div class="card-header">
                <h5 style="margin-bottom: 0px;">{{ $data['event']->name }}</h5>
              </div>
            </a>
            <div class="card-body">

              @if ($data['topTeam'])
                  <p style="margin-bottom: 0px;"><strong>Équipe avec le plus de points : {{ $data['topTeam']->team->name }} ({{ $data['topTeam']->total_points }} points)</strong></p>
              @else
                  <p style="margin-bottom: 0px;">Aucune équipe n'a encore de points pour cette épreuve.</p>
              @endif
            </div>
          </div>
        @empty
          <div class="card">
            <div class="card-body">
              <h5 class="m-0">Aucune épreuve encore passée</h5>
            </div>
          </div>
        @endforelse
        </div>
      </div>
    <br>

  <div class="card">
    <div class="card-body">
      <div class="d-flex align-items-center justify-content-between">
        <h5 class="card-subtitle mb-2 text-muted">Classement des Médailles</h5>
        <button style="padding-bottom:2px;padding-top:2px;margin-bottom: 6px;margin-top: -9px;width: 145px;" id="toggleTeamComponent" class="btn btn-outline-secondary float-end">Équipe</button>
      </div>
      @if ($medalStandings->count() > 0)
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th class="teamNameHeader">Équipe</th>
                    <th class="teamComponentHeader" style="display: none;">Composante</th>
                    <th><i class="fas fa-medal" style="color: gold;"></i> Or</th>
                    <th><i class="fas fa-medal" style="color: silver;"></i> Argent</th>
                    <th><i class="fas fa-medal" style="color: #cd7f32;"></i> Bronze</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($medalStandings as $key => $medalStanding)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>
                            <a href="{{ route('teams.show', ['team' => $medalStanding->team->id]) }}">
                                @if ($medalStanding->team->logo)
                                    <img class="teamLogo rounded-circle" src="{{ asset('storage/teams/' . $medalStanding->team->logo) }}" alt="{{ $medalStanding->team->name }} Logo" width="25" style="margin-right: 8px;">
                                @else
                                    <img class="teamLogo rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                @endif
        
                                {{-- Utilisez une classe spécifique pour le <td> afin de le cibler avec JavaScript --}}
                                <span class="teamName">{{ $medalStanding->team->name }}</span>
                                <span class="teamComponent" style="display: none;">{{ $medalStanding->team->composante }}</span>
                            </a>
                        </td>
                        <td>{{ $medalStanding->gold_count }}</td>
                        <td>{{ $medalStanding->silver_count }}</td>
                        <td>{{ $medalStanding->bronze_count }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        
        <script>
            $(document).ready(function () {
                //toogle entre composante et equipe, pareil que pour la page rank
                $('#toggleTeamComponent').on('click', function () {
                    $('.teamNameHeader, .teamComponentHeader').toggle();
                    $('.teamComponent').toggle();
                    $('.teamLogo').toggle();
        
                    var buttonText = ($(this).text() === 'Équipe') ? 'Composante' : 'Équipe';
                    $(this).text(buttonText);
                });
            });
        </script>               
      @else
          <p class="alert alert-info">Aucune médaille disponible.</p>
      @endif
    </div>
  </div>
  <br>

  @if ($events->isNotEmpty())
  <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/core@6.1.9/index.global.min.js'></script>
  <script src='https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@6.1.9/index.global.min.js'></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
          locale: 'fr', 
          validRange: {
                    start: '{{$firstEvent}}',
                    end: '{{$lastEvent}}'
                },
                events: [
                  @foreach ($events as $event)
                        {
                            title: '{{$event->name}}',
                            start: '{{$event->date}}',
                            url: '{{ route("events.show", ["event" => $event->id]) }}',
                        },
                    
                  @endforeach
                ],
        });
        calendar.render();
      });

    </script>
    <div class="card">
      <div class="card-body">
        <div id='calendar'></div>
      </div>
    </div>
    <br>
  @endif

</div>
@endsection