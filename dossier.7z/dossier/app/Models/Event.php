<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Medal;

class Event extends Model {
    use HasFactory;
    
    protected $fillable = ['name', 'date', 'sport'];

    public function rounds() {
        return $this->hasMany(Round::class);
    }

    public function teams() {
        return $this->belongsToMany(Team::class);
    }
    public function medals() {
        return $this->hasMany(Medal::class);
    }
    protected static function boot()
    {
        parent::boot();

        static::deleting(function ($event) {
            // supprime medaille de l'event (marche pas)
            $event->medals()->delete();
            $event->rounds->each(function ($round) {
                $round->results()->delete();
            });
            $event->rounds()->delete();
        });
        
    }
}