@extends('teams.template')
@section('content')

@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Liste des équipes</h2>
    
    <div class="input-group mb-3">
        <input type="text" id="searchInput" class="form-control mb-3" placeholder="Rechercher par nom d'équipe">
    </div>

    <div id="teamsContainer">
        @foreach ($teams as $team)
            <a href="{{ route('teams.show', ['team' => $team->id]) }}" class="card mb-4 text-decoration-none text-dark">
                <div class="card-body d-flex align-items-center">
                    @if (!empty($team->logo))
                        <img src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }}" class="img-fluid mb-3 rounded-circle" style="max-width: 50px; margin-right: 15px; margin-bottom:0px !important;">
                    @else
                        <img src="{{ asset('storage/teams/default.png') }}" alt="Image par défaut" class="img-fluid mb-3 rounded-circle" style="max-width: 50px; margin-right: 15px; margin-bottom:0px !important;">
                    @endif
                    <h2 class="card-title mb-0">{{ $team->name }} <small>({{ $team->users->count() }} membres)</small></h2>
                    <div class="ml-auto">
                        <i class="fas fa-medal" style="color: gold;" title="Or"></i>{{ $team->medals->where('type', 'gold')->count() }}
                        <i class="fas fa-medal" style="color: silver;" title="Argent"></i>{{ $team->medals->where('type', 'silver')->count() }}
                        <i class="fas fa-medal" style="color: #cd7f32;" title="Bronze"></i>{{ $team->medals->where('type', 'bronze')->count() }}
                    </div>
                </div>
            </a>
        @endforeach
    </div>
</div>

<script>
    $(document).ready(function() {
        //A FAIRE : utiliser du ajax a la place
        $('#searchInput').on('input', function() {
            var searchText = $(this).val().toLowerCase();

            $('.card.text-decoration-none').each(function() {
                var teamName = $(this).find('.card-title').text().toLowerCase();
                
                if (teamName.includes(searchText)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    });
</script>



@endsection