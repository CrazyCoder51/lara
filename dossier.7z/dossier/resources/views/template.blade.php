<!DOCTYPE html>
<html lang="fr">
  <head>
    <title>@yield('title')</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    @yield('AdditionalHead')
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/7ee7ccadf7.js" crossorigin="anonymous"></script>
    <link href='https://unpkg.com/css.gg@2.0.0/icons/css/log-in.css' rel='stylesheet'>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="{{asset('storage/css/style.css')}}">
    <script defer src="{{asset('storage/js/script.js')}}"></script>
    <link rel="icon" type="image/x-icon" href="{{asset('storage/images/logo.png')}}">
    <meta name="theme-color" content="#C4C4C4">
    <script src="https://cdn.jsdelivr.net/npm/party-js@latest/bundle/party.min.js"></script>
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&amp;display=swap" rel="stylesheet">
    @yield('AdditionalHeadEnd')

  </head>
  @yield('curseur-header')
  <body>
    <div class="head">
      <div class="headContent">
        <nav>
          <div class="headLogo">
            <a href="{{ route('index') }}"><img onmouseenter="party.sparkles(this)" id="logo" src="{{asset('storage/images/logo.png')}}" alt="LOGO"></a>
          </div>
          <ul class="nav-ele-list" id="navi-list">
            <li class="nav-ele">
              <a class=" nav-link @if($curseur==1) nav-link-current @endif" href="{{ route('index') }}">Accueil</a>
            </li>
            <li  class="nav-ele" >
              <a class=" nav-link @if($curseur==2) nav-link-current @endif" href="{{ route('news') }}">Actualités</a>
            </li>
            <li  class="nav-ele" >
              <a class=" nav-link @if($curseur==3) nav-link-current @endif" href="{{ route('teams') }}">Équipes</a>
            </li>
            <li  class="nav-ele" >
              <a class=" nav-link @if($curseur==4) nav-link-current @endif" href="{{ route('events') }}">Épreuves</a>
            </li>
            <li  class="nav-ele" >
              <a class=" nav-link @if($curseur==5) nav-link-current @endif" href="{{ route('rank') }}">Classements</a>
            </li>
            <li  class="nav-ele" >
              <a class=" nav-link @if($curseur==6) nav-link-current @endif" href="{{ route('support') }}">Support</a>
            </li>
            @guest
              <li  class="nav-ele nav-ele-hidden">
                <a class="nav-link" href="{{ route('login') }}"><i class="fas fa-sign-in-alt"></i> Se connecter</a>
              </li>
            @endguest
            @auth
              @if (!empty(Auth::user()->team_id))
                <li  class="nav-ele nav-ele-hidden">
                  <a class=" nav-link @if($curseur=="myTeam") nav-link-current @endif" href="{{ route('myTeam') }}"><i class="nav-i fa-solid fa-user-group"></i> Mon équipe</a>
                </li>
              @endif
              <li  class="nav-ele nav-ele-hidden">
                <a class=" nav-link @if($curseur=="account") nav-link-current @endif" href="{{ route('account') }}" ><i class="nav-i fa-solid fa-user"></i> Mon compte</a> 
              </li>
            @endauth
          </ul>
          <div class="nav-ele" id="backgroundButton"></div>
          <div class="nav-menu" id="toggleButton">
            <div class="nav-menu-line"></div>
            <div class="nav-menu-line"></div>
            <div class="nav-menu-line"></div>
          </div>
        </nav>
        <div>
          <ul class="nav-ele-list" id="navi-list">
          @guest
          <li  class="nav-ele">
            <a class='nav-link' href="{{ route('login') }}"><i class="fas fa-sign-in-alt" style="margin-right: 7px;"></i> Se connecter</a>
          </li>
          @else
            @if (!empty(Auth::user()->team_id))
            <li  class="nav-ele">
              <a class=" nav-link @if($curseur=="myTeam") nav-link-current @endif" href="{{ route('myTeam') }}"><i class="nav-i fa-solid fa-user-group"></i> Mon équipe</a>
            </li>
            @endif
            <li  class="nav-ele">
              <a class=" nav-link @if($curseur=="account") nav-link-current @endif" href="{{ route('account') }}"><i class="nav-i fa-solid fa-user"></i> Mon compte</a> 
            </li>
          @endguest
          </ul>
        </div>
      </div>
    </div>
    
      <div class="space-header"></div>
    
      <div class="content">
        @yield('content')
      </div>
  </body>
</html>