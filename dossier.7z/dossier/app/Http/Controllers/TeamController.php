<?php

namespace App\Http\Controllers;

use App\Models\Team;
use App\Models\User;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TeamController extends Controller
{
    public function index()
    {
        $teams = Team::all();
        return view('teams.index', compact('teams'));
    }

    public function indexAdmin(){
        $teams = Team::all();

        $users = User::all();

        $usersWithTeams = User::has('team')->get();

        return view('admin.teams', ['teams' => $teams, 'users' => $users,'usersWithTeams' => $usersWithTeams]);
    }

    public function indexMyTeam(){
        return view('myteam');
    }

    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'name' => 'required',
                'composante' => 'required',
            ]);
            $team = Team::create([
                'name' => $request->input('name'),
                'composante' => $request->input('composante'),
            ]);
    
            return redirect()->back()->with('success', 'L\'equipe a bien été créé.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur s\'est produite lors de la création de l\'equipe.');
        }
    }

    public function show($id)
    {
        $team = Team::findOrFail($id);
        
        // Recuperer manches de l'équipe + info sur l'épreuve
        $rounds = $team->rounds()->with('event')->get();

        $totalPoints = $team->getTotalPoints();

        return view('teams.show', compact('team', 'rounds','totalPoints'));
    }

    public function edit($id)
    {
        $users = User::all();
        $team = Team::findOrFail($id);
        return view('admin.teams.edit', compact('team','users'));
    }

    public function destroy(Request $request)
    {
        $teamId = $request->input('team_id');
        
        $team = Team::find($teamId);

        if (!$team) {
            return redirect()->back()->with('error', 'Équipe non trouvée : '.$request);
        }

        // Recupere users de l'equipe
        $users = $team->users;

        // enlever la team des users (team_id de user a NULL)
        foreach ($users as $user) {
            $user->team_id = null;
            $user->save();
        }

        // Supprimer l'equipe
        $team->delete();

        return redirect()->back()->with('success', 'Équipe supprimée avec succès');
    }
    public function addUser(Request $request)
    {
        $user = User::find($request->input('user_id'));
        $team = Team::find($request->input('team_id'));

        if ($user && $team) {
            $user->team_id = $team->id;
            $user->save();

            return redirect()->back()->with('success', 'Utilisateur ajouté à l\'équipe avec succès');
        } else {
            return redirect()->back()->with('error', 'Erreur lors de l\'ajout de l\'utilisateur à l\'équipe');
        }
    }
    public function removeUser(Request $request)
    {
        $userId = $request->input('user_id');
        $user = User::find($userId);

        if ($user) {
            // enlever la team des users (team_id de user a NULL)
            $user->team_id = null;
            $user->save();
            return redirect()->back()->with('success', 'Utilisateur supprimé de l\'équipe avec succès');
        } else {
            return redirect()->back()->with('error', 'Erreur lors de la suppression de l\'utilisateur de l\'équipe');
        }
    }
    public function update(Request $request){
            $validatedData = $request->validate([
                'logoInput' => 'image|mimes:jpeg,png,jpg,gif|max:2048', 
            ]);

            $team = Auth::user()->team;
            
            //MAJ LOGO SI DONNé
            if ($request->hasFile('logoInput')) {
                $logo = $request->file('logoInput');
                $extension = $logo->getClientOriginalExtension();
                $randomFileName = Str::random(30) . '.' . $extension;
                $logoPath = public_path('storage/teams/' . $randomFileName);

                // redimensionné logo
                Image::make($logo)->fit(250, 250)->save($logoPath);

                // maj dans la bd
                $team->logo = $randomFileName;
            }

            //MAJ BIO SI DONNé
            if ($request->filled('bio')) {
                $team->bio = $request->input('bio');
            }
            else{
                $team->bio = NULL;
            }

            $team->save();

            return redirect()->back()->with('success', 'Mis à jour avec succès.');
    }

    public function updateAdmin(Request $request, Team $team)
    {
        try{
            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'composante' => 'required|string|max:255',
            ]);

            $team->update($validatedData);

            return redirect()->back()->with('success', 'Équipe mise à jour avec succès');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenu');
        }
    }
        public function removeLogo($teamId)
    {
        $team = Team::findOrFail($teamId);
        
        // LA METHOSE SE TROUVE DANS LE MODEL
        $team->removeLogo();

        return redirect()->back()->with('success', 'Logo de l\'équipe supprimé avec succès');
    }
    public function getTeamsData(Request $request)
    {
        $query = Team::query();

        $query->select('teams.id', 'teams.name', 'teams.composante', 'teams.logo');

        // Filtrage par nom
        if ($request->has('search.value')) {
            $query->where('teams.name', 'like', '%' . $request->input('search.value') . '%');
        }

        // Triage par colonne
        if ($request->has('order.0.column') && $request->has('order.0.dir')) {
            $orderColumn = $request->input('order.0.column');
            $orderDirection = $request->input('order.0.dir');
            $query->orderBy($request->input("columns.$orderColumn.data"), $orderDirection);
        }

        // nombre par page
        $perPage = $request->input('length');
        $page = $request->input('start') / $perPage + 1;
        $teams = $query->paginate($perPage, ['*'], 'page', $page);

        $data = $teams->map(function ($team) {
            return [
                'id' => $team->id,
                'name' => $team->name,
                'composante' => $team->composante,
                'logo' => $team->logo,
                'team_size' => $team->users->count(),
            ];
        });
        

        return response()->json([
            'draw' => $request->input('draw'),
            'recordsTotal' => $teams->total(),
            'recordsFiltered' => $teams->total(),
            'data' => $data,
        ]);
    }
}
