<?php

namespace Database\Factories;

use App\Models\Team;
use App\Models\Result;
use App\Models\Round;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\DB;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Result>
 */
class ResultFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $pivotEntry = DB::table('teams_rounds')
            ->whereNotIn('team_id', Result::pluck('team_id')->toArray())
            ->whereNotIn('round_id', Result::pluck('round_id')->toArray())
            ->inRandomOrder()
            ->first();

        return [
            'round_id' => $pivotEntry->round_id,
            'team_id' => $pivotEntry->team_id,
            'score' => $this->faker->numberBetween(0, 100),
            'points' => $this->faker->numberBetween(0, 10),
        ];
    }
}
