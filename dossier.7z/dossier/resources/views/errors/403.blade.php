<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Jeux de l'URCA - Erreur 403</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="{{asset('storage/css/style.css')}}">
        <link rel="icon" type="image/x-icon" href="{{asset('storage/images/logo.png')}}">
        <meta name="theme-color" content="#C4C4C4">
    </head>
    <body>
        <div class="container">
            <br><br>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Erreur 403 - Accès interdit</div>

                        <div class="card-body">
                            <p>Désolé, vous n'avez pas l'autorisation d'accéder à cette page.</p>
                            <a href="{{ url('/') }}">Retour à la page d'accueil</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>