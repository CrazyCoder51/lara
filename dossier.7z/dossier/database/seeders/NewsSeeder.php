<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\News;

class NewsSeeder extends Seeder
{
    public function run()
    {   
        News::factory()->count(10)->create();
        News::create([
            'title' => 'Actualité 1',
            'content' => 'Contenu de l\'actualité 1.',
        ]);

        News::create([
            'title' => 'Actualité 2',
            'content' => 'Contenu de l\'actualité 2.',
        ]);

        // Ajoutez d'autres actualités selon vos besoins
    }
}