@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('AdditionalHeadEnd')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <meta name="csrf-token" content="{{ csrf_token() }}">
@endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Utilisateurs</h2>

        <div class="mb-3">
            @if(session('error'))
                <div class="alert alert-danger" role="alert">
                    {{ session('error') }}
                </div>
            @endif

            @if(session('success'))
                <div class="alert alert-success" role="alert">
                    {{ session('success') }}
                    @if(session('email') && session('password'))
                        <a href="mailto:{{session('email')}}?subject=Jeux de l'URCA : Votre compte&body=Voici votre mot de passe pour vous connecter sur la plateforme des Jeux de L'URCA : {{session('password')}}%0APour vous connecter, utilisez votre adresse e-mail de l'URCA">Envoyer un mail.</a>
                    @endif
                </div>
            @endif
        </div>

        <a class="text-secondary mb-4" href="{{route('admin')}}">🠔 Retour</a>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Créer un utilisateur</h3>
                <form method="post" action="{{ route('admin.users.create') }}">
                    @csrf
                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Nom:</label>
                        <input type="text" class="form-control" name="name" id="name" required>
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" name="role" id="role">
                        <label class="form-check-label" for="role">Organisateur</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Créer l'utilisateur</button>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <h3>Liste des utilisateurs</h3>
            
            <input type="text" id="searchInput" class="form-control mb-3" placeholder="Rechercher par nom d'utilisateur">

            <table id="usersTable" class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Image</th>
                        <th>Mail</th>
                        <th>Équipe</th> 
                        <th>Actions</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>

    <form id="deleteForm" method="post" action="{{ route('admin.users.delete') }}" style="display: none;">
        @csrf
        @method('DELETE')
        <input type="hidden" id="userId" name="user_id">
    </form>
    
    <script>
        $(document).ready(function () {
            // JETON OBLIGATOIRE
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
    
            var table = $('#usersTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route("admin.users.data") }}',
                    type: 'POST',
                },
                columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    {
                        data: null,
                        render: function (data, type, row) {
                            return '<img style="width: 31px;margin-left: 6px;" src="' + "{{ asset('storage/avatars/') }}/" + row.avatar + '">';
                        },
                        orderable: false,
                    },
                    { data: 'email', name: 'email' },
                    { data: 'team_name', name: 'team.name' },
                    {
                        data: null,
                        render: function (data, type, row) {
                            return '<a style="margin-right:5px;"href="{{ route("admin.users.edit.url") }}/' + row.id + '" class="btn btn-primary btn-sm edit-btn">Modifier</a>'+
                            '<button class="btn btn-danger btn-sm delete-btn" data-id="' + row.id + '">Supprimer</button>';
                        },
                        orderable: false,
                    },
                ],
            });
    
            $('#searchInput').on('keyup', function () {
                table.search(this.value).draw();
            });
    
            // Gestionnaire d'événements pour le clic sur le bouton de suppression
            $('#usersTable').on('click', '.delete-btn', function () {
                var userId = $(this).data('id');
    
                // Remplir l'input hidden avec l'ID de l'utilisateur à supprimer
                $('#userId').val(userId);
    
                // Soumettre le formulaire de suppression
                $('#deleteForm').submit();
            });
        });
    </script>
    
@endsection
