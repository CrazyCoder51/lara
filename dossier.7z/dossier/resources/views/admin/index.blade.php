@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')

    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel</h2>
        <div class="card">
            <div class="card-body">
                <div class="mb-4">
                    <a style="color:white" style="" href="{{route('admin.users')}}" class="btn btn-primary btn-block btn-config">Utilisateurs</a>
                </div>

                <div class="mb-4">
                    <a style="color:white" href="{{route('admin.teams')}}" class="btn btn-primary btn-block btn-config">Équipes</a>
                </div>

                <div class="mb-4">
                    <a style="color:white" href="{{route('admin.news')}}" class="btn btn-primary btn-block btn-config">Actualités</a>
                </div>

                <div class="mb-4">
                    <a style="color:white" href="{{route('admin.events')}}" class="btn btn-primary btn-block btn-config">Épreuves</a>
                </div>

                <div class="mb-4">
                    <a style="color:white" href="{{route('admin.results')}}" class="btn btn-primary btn-block btn-config">Résultats</a>
                </div>

                <div class="mb-4">
                    <a style="color:white" href="{{route('admin.medals')}}" class="btn btn-primary btn-block btn-config">Médailles</a>
                </div>
            </div>
        </div>

    </div>
@endsection