@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Épreuves</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin')}}">🠔 Retour</a>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Ajouter une nouvelle épreuve</h3>
                <form method="POST" action="{{ route('admin.events.create') }}">
                    @csrf
        
                    <div class="form-group">
                        <label for="name">Nom de l'épreuve</label>
                        <input type="text" name="name" id="name" class="form-control" required>
                    </div>
        
                    <div class="form-group">
                        <label for="date">Date de l'épreuve</label>
                        <input type="date" name="date" id="date" class="form-control" required>
                    </div>
        
                    <div class="form-group">
                        <label for="sport">Sport de l'épreuve</label>
                        <input type="text" name="sport" id="sport" class="form-control" required>
                    </div>
        
                    <button type="submit" class="btn btn-primary">Ajouter l'épreuve</button>
                </form>
            </div>
        </div>
        
        @if ($events->count() > 0)
            <div class="table-responsive mt-4">
                <h3 class="card-title">Liste des épreuves</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Date</th>
                            <th>Sport</th>
                            <th>Nombre de Manches</th>
                            <th>Modifier</th>
                            <th>Supprimer</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($events as $event)
                            <tr>
                                <td>{{ $event->id }}</td>
                                <td>{{ $event->name }}</td>
                                <td>{{ $event->date }}</td>
                                <td>{{ $event->sport }}</td>
                                <td>{{ $event->rounds->count() }}</td>
                                <td><a href="{{ route('admin.events.edit', ['id' => $event->id]) }}" class="btn btn-primary">Modifier</a></td>
                                <td>
                                    <form action="{{ route('admin.events.delete', ['id' => $event->id]) }}" method="post">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette épreuve ?')">Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p>Aucune épreuve disponible.</p>
        @endif
    </div>
@endsection
