@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Médailles</h2>

        @if(session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        @if(session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin')}}">🠔 Retour</a>

        <div class="card mb-4">
            <div class="card-body">
                <h3 class="card-title">Créer une médaille</h2>
                <form action="{{ route('admin.medals.create') }}" method="POST">
                    @csrf

                    <div class="form-group">
                        <label for="event_id">Événement :</label>
                        <select name="event_id" id="event_id" class="form-control">
                            @foreach ($events as $event)
                                <option value="{{ $event->id }}">{{ $event->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="team_id">Équipe :</label>
                        <select name="team_id" id="team_id" class="form-control">
                            @foreach ($teams as $team)
                                <option value="{{ $team->id }}">{{ $team->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="type">Type de Médaille :</label>
                        <select name="type" id="type" class="form-control">
                            <option value="gold">Or</option>
                            <option value="silver">Argent</option>
                            <option value="bronze">Bronze</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Ajouter Médaille</button>
                </form>
            </div>
        </div>


        @if ($medals->count() > 0)
            <div class="table-responsive mt-4">
                <h3>Liste des médailles</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Événement</th>
                            <th>Équipe</th>
                            <th>Type</th>
                            <th>Supprimer</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($medals as $key => $medal)
                            <tr>
                                <td>{{ $key + 1 }}</td>
                                <td>{{ $medal->event->name }}</td>
                                <td>{{ $medal->team->name }}</td>
                                <td>{{ ucfirst($medal->type) }}</td>
                                <td>
                                    <form method="post" action="{{ route('admin.medals.delete', ['medal' => $medal->id]) }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p>Aucune médaille disponible.</p>
        @endif
    </div>
@endsection
