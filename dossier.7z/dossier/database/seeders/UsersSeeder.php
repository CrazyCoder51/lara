<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Spatie\Permission\Models\Role;

class UsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // creer role joueur
        $joueurRole = Role::firstOrCreate(['name' => 'joueur']);

        // creer role organizer
        $organisateurRole = Role::firstOrCreate(['name' => 'organizer']);

        // creer user joueur
        $joueurUser = User::create([
            'name' => 'Utilisateur JOueur',
            'email' => 'joueur@gmail.com',
            'password' => bcrypt('password'), // bcrypt -> hash pour pas avoir le mdp en clair dans la bd
            'avatar' => 'default.png',
        ]);
        $joueurUser->assignRole($joueurRole);

        // creer user organizer
        $organisateurUser = User::create([
            'name' => 'Utilisateur Organisateur',
            'email' => 'orga@gmail.com',
            'password' => bcrypt('password'), // bcrypt -> hash pour pas avoir le mdp en clair dans la bd
            'avatar' => 'default.png',
        ]);
        $organisateurUser->assignRole($organisateurRole);

        
        $theo = User::create([
            'name' => 'theo',
            'email' => 'theo@gmail.com',
            'password' => bcrypt('password'),
            'avatar' => 'default.png',
        ]);
        $theo->assignRole($organisateurRole);

        User::factory(10)->create()->each(function ($user) use ($joueurRole) {
            $user->assignRole($joueurRole);
        });
    }
}
