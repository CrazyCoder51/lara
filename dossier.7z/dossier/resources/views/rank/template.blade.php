@extends('template')
@section('title') Jeux de l'URCA - Classements @endsection
@section('curseur-header')
    @php
        $curseur = 5;
    @endphp
@endsection
@section('content')
@yield('content')
@endsection