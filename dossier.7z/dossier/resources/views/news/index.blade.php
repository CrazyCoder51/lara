@extends('template')
@section('title') Jeux de l'URCA - Actualités @endsection
@section('curseur-header')
    @php
        $curseur = 2;
    @endphp
@endsection
@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Actualités</h2>

    <div class="d-flex mb-3">
        <button class="btn btn-primary mr-2" id="sortChrono">Trier par ordre chronologique</button>
        <button class="btn btn-primary" id="sortReverseChrono">Trier par ordre déchronologique</button>
    </div>

    <div class="row">
        @foreach ($news as $newsItem)
            <div class="col-md-6 mb-4">
                <div class="card">
                    <a href="{{ route('news.show', ['news' => $newsItem->id]) }}">
                        @if (!empty($newsItem->image))
                            <img src="{{ asset('storage/news/' . $newsItem->image) }}" alt="{{ $newsItem->title }}" class="card-img-top img-fluid">
                        @else
                            <img src="{{ asset('storage/news/default.png') }}" alt="Image par défaut" class="card-img-top img-fluid">
                        @endif
                    </a>

                    <div class="card-body">
                        <h2 class="card-title">
                            <a href="{{ route('news.show', ['news' => $newsItem->id]) }}">{{ $newsItem->title }}</a>
                        </h2>
                        <time datetime="{{ $newsItem->created_at->toIso8601String() }}">{{ $newsItem->created_at->formatLocalized('%d %B %Y') }}</time>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

<script>
    //script volé pour trier, utiliser du ajax à la place
    document.addEventListener("DOMContentLoaded", function () {
        var sortChronoButton = document.getElementById("sortChrono");
        var sortReverseChronoButton = document.getElementById("sortReverseChrono");

        sortChronoButton.addEventListener("click", function () {
            sortNewsByDate(true);
        });

        sortReverseChronoButton.addEventListener("click", function () {
            sortNewsByDate(false);
        });

        function sortNewsByDate(ascending) {
            var newsContainer = document.querySelector(".row");
            var newsItems = Array.from(newsContainer.getElementsByClassName("col-md-6"));

            newsItems.sort(function (a, b) {
                var dateA = new Date(a.querySelector(".card-body time").getAttribute("datetime"));
                var dateB = new Date(b.querySelector(".card-body time").getAttribute("datetime"));

                return ascending ? dateA - dateB : dateB - dateA;
            });

            newsItems.forEach(function (item) {
                newsContainer.appendChild(item);
            });
        }
    });
</script>


@endsection