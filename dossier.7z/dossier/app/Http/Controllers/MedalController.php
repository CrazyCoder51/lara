<?php

namespace App\Http\Controllers;

use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Result;
use App\Models\Event;
use App\Models\Medal;

class MedalController extends Controller
{
    public function indexAdmin()
    {
        $events = Event::all();
        $teams = Team::all();
        $medals = Medal::all();

        return view('admin.medals', compact('events', 'teams', 'medals'));
    }
    public function store(Request $request)
    {
        try {
            $request->validate([
                'event_id' => 'required|exists:events,id',
                'type' => [
                    'required',
                    'in:gold,silver,bronze',
                    Rule::unique('medals')->where(function ($query) use ($request) {
                        return $query->where('event_id', $request->input('event_id'));
                    }),
                ],
            ]);

            //creation de la medaille
            Medal::create([
                'event_id' => $request->input('event_id'),
                'team_id' => $request->input('team_id'),
                'type' => $request->input('type'),
            ]);

            return redirect()->back()->with('success', 'Médaille ajoutée avec succès.');
        } catch (\Exception $e) {
                // si medaillle existe deja -> cette erreur
            if (strpos($e->getMessage(), 'type') !== false) {
                return redirect()->back()->with('error', 'Une médaille de ce type a déjà été décernée pour cet événement.');
            }
            return redirect()->back()->with('error', 'Une erreur est survenue');
        }
    }
    public function destroy(Medal $medal)
    {
        try{
            $medal->delete();

            return redirect()->back()->with('success', 'La médaille a été supprimé avec succès');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur c\'est produite');
        }
    }
}
