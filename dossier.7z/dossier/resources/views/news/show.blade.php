@extends('template')
@section('title') Jeux de l'URCA - Actu : {{ $news->title }} @endsection
@section('curseur-header')
    @php
        $curseur = 2;
    @endphp
@endsection
@section('content')
<div class="container mt-4">
    <a class="text-secondary mb-4" href="{{route('news')}}">🠔 Actualitées</a>
    <div class="card">
        @if (!empty($news->image))
            <img src="{{ asset('storage/news/' . $news->image) }}" alt="{{ $news->title }}" class="card-img-top img-fluid">
        @else
            <img src="{{ asset('storage/news/default.png') }}" alt="Image par défaut" class="card-img-top img-fluid">
        @endif

        <div class="card-body">
            <h2 class="card-title">{{ $news->title }}</h2>
            <p class="card-text">{{ $news->content }}</p>
        </div>

        <div class="card-footer text-muted">
            <small>Publié le {{ $news->created_at->format('d/m/Y H:i') }}</small>
        </div>
    </div>

    <div class="mt-4">
        <h4>Autres actualitées</h4>
        <div class="row">
            {{-- Boucle pour afficher les 5 dernières actualités --}}
            @foreach ($latestNews as $latest)
                @if($latest->id != $news->id)
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <a href="{{ route('news.show', ['news' => $latest->id]) }}">
                                @if (!empty($latest->image))
                                    <img src="{{ asset('storage/news/' . $latest->image) }}" alt="{{ $latest->title }}" class="card-img-top img-fluid">
                                @else
                                    <img src="{{ asset('storage/news/default.png') }}" alt="Image par défaut" class="card-img-top img-fluid">
                                @endif
                            </a>

                            <div class="card-body">
                                <a href="{{ route('news.show', ['news' => $latest->id]) }}">
                                    <h5 class="card-title">{{ $latest->title }}</h5>
                                    <p class="card-text"><small class="text-muted">Publié le {{ $latest->created_at->format('d/m/Y H:i') }}</small></p>
                                </a>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    </div>
</div>
@endsection