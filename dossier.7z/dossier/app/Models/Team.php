<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Round;
use App\Models\Result;
use App\Models\Medal;

class Team extends Model
{
    use HasFactory;

    protected $fillable = ['name','logo','bio','composante'];

    public function users()
    {
        return $this->hasMany(User::class);
    }
    public function rounds()
    {
        return $this->belongsToMany(Round::class, 'teams_rounds');
    }
    public function medals()
    {
        return $this->hasMany(Medal::class);
    }
    public function results()
    {
        return $this->hasMany(Result::class);
    }

    public function removeLogo()
    {
        $this->update(['logo' => null]);

        return $this;
    }

    protected static function boot()
    {
        parent::boot();

        static::deleting(function ($team) {
            //supprime les differentes relations
            $team->rounds()->detach();

            $team->results()->delete();

            $team->medals()->delete();
        });
    }
    public function getTotalPoints()
    {
        $results = $this->results;
        $totalPoints = $results->sum('points');

        return $totalPoints;
    }
}
