<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Storage;
use App\Models\News;
use GuzzleHttp\Client;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\News>
 */
class NewsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $randomFileName = Str::random(30) . '.jpg'; // genere nom fichier aleatoire

        $imagePath = "{$randomFileName}"; // path avec le nouveau nom de fichier

        // DL de l'image
        $client = new Client([
    		'base_uri' => 'https://picsum.photos/',
    		'verify'   => base_path('certificates/cacert.pem'),
	]);
        $response = $client->get('1000/500');

        // Save de l'image
        Storage::put("public/news/{$imagePath}", $response->getBody());

        //pour la date de l'actu
        $lastMonth = now()->subMonth();

        return [
            'title' => $this->faker->sentence,
            'content' => $this->faker->text(500),
            'image' => $imagePath,
            'created_at' => $this->faker->dateTimeBetween($lastMonth, 'now'),
        ];
    }
}
