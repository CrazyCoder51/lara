@extends('template')
@section('title') Jeux de l'URCA - Admin Panel @endsection
@section('curseur-header')
    @php
        $curseur = 0;
    @endphp
@endsection
@section('content')
    <div class="container mt-5">
        <h2 class="mt-4">Admin Panel : Actualités</h2>
        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <a class="text-secondary mb-4" href="{{route('admin')}}">🠔 Retour</a>

        <div class="card mb-3">
            <div class="card-header">
                <h2>Ajouter une nouvelle actualité</h2>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('admin.news.create') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="mb-3">
                        <label for="title" class="form-label">Titre de l'actualité</label>
                        <input type="text" name="title" id="title" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="content" class="form-label">Contenu de l'actualité</label>
                        <textarea name="content" id="content" class="form-control" rows="5" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Image de l'actualité</label>
                        <input type="file" name="image" id="image" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary">Ajouter l'actualité</button>
                </form>
            </div>
        </div>

        <h2 class="mt-4">Liste des actualités</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titre</th>
                    <th>Modifier</th>
                    <th>Supprimer</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($news as $newsItem)
                    <tr>
                        <td>{{ $newsItem->id }}</td>
                        <td>{{ $newsItem->title }}</td>
                        <td><a href="{{ route('admin.news.edit', $newsItem->id) }}" class="btn btn-warning">Modifier</a></td>
                        <td>
                            <form method="post" action="{{ route('admin.news.delete', ['news' => $newsItem->id]) }}">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <h2 class="mt-4">Détails des actualités</h2>
        @foreach ($news as $newsItem)
            <div class="card mb-3">
                <div class="card-header">
                    <h2>{{ $newsItem->id }} : {{ $newsItem->title }}</h2>
                </div>
                <div class="card-body">
                    <p>{{ $newsItem->content }}</p>
                    @if (!empty($newsItem->image))
                        <img src="{{ asset('storage/news/' . $newsItem->image) }}" alt="{{ $newsItem->title }}" class="img-fluid mb-3">
                    @else
                        <img src="{{ asset('storage/news/default.png') }}" alt="Image par défaut" class="img-fluid mb-3">
                    @endif
                </div>
            </div>
        @endforeach
    </div>
@endsection
