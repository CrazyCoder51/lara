@extends('template')
@section('title') Jeux de l'URCA - Teams @endsection
@section('curseur-header')
    @php
        $curseur = 3;
    @endphp
@endsection
@section('content')
@yield('content')
@endsection