<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Client;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Team>
 */
class TeamFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $randomFileName = Str::random(30) . '.jpg'; // genere nom fichier aleatoire

        $imagePath = "{$randomFileName}";  // path avec le nouveau nom de fichier

        // DL de l'image
        $client = new Client([
    		'base_uri' => 'https://picsum.photos/',
    		'verify'   => base_path('certificates/cacert.pem'),
	]);
        $response = $client->get('250/250');

        // Save de l'image
        Storage::put("public/teams/{$imagePath}", $response->getBody());

        return [
            'name' => $this->faker->unique()->word,
            'composante' => $this->faker->unique()->word,
            'logo' => $imagePath,
        ];
    }
}
