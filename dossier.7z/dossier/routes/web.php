<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\RoundController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\RankController;
use App\Http\Controllers\MedalController;
use App\Http\Middleware\CheckRole;
use App\Http\Middleware\CheckTeam;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('support', function () { return view('support');})->name('support');

Route::get('forger-password', function () { return view('auth.forgot-password');})->name('password.request');

Route::middleware([CheckRole::class.':organizer'])->group(function () {
    ////////////ADMIN
    Route::get('admin', [AdminController::class, 'index'])->name('admin');

    //NEWS
    Route::get('admin/news', [NewsController::class, 'indexAdmin'])->name('admin.news');

    Route::post('admin/news/create', [NewsController::class, 'store'])->name('admin.news.create');

    Route::get('admin/news/edit/{news}', [NewsController::class, 'edit'])->name('admin.news.edit');

    Route::post('admin/news/update/{news}', [NewsController::class, 'update'])->name('admin.news.update');

    Route::delete('admin/news/delete/{news}', [NewsController::class, 'destroy'])->name('admin.news.delete');

    //TEAMS
    Route::post('/admin/teams/data', [TeamController::class, 'getTeamsData'])->name('admin.teams.data');

    Route::get('admin/teams', [TeamController::class, 'indexAdmin'], )->name('admin.teams');

    Route::get('admin/teams/edit/{team}', [TeamController::class, 'edit'])->name('admin.teams.edit');

    Route::get('admin/teams/edit/', [TeamController::class, 'edit'])->name('admin.teams.edit.url'); // SEULEMENT POUR L'URL

    Route::post('admin/teams/update/{team}', [TeamController::class, 'updateAdmin'])->name('admin.teams.update');

    Route::post('admin/teams/create', [TeamController::class, 'store'])->name('admin.teams.create');

    Route::delete('admin/teams/delete/', [TeamController::class, 'destroy'])->name('admin.teams.delete');

    Route::post('admin/teams/add-user', [TeamController::class, 'addUser'])->name('admin.teams.add-user');

    Route::delete('admin/teams/remove-user', [TeamController::class, 'removeUser'])->name('admin.teams.remove-user');

    Route::post('admin/teams/remove-logo/{team}', [TeamController::class, 'removeLogo'])->name('admin.teams.remove-Logo');

    //USER
    Route::post('/admin/users/data', [ProfileController::class, 'getUsersData'])->name('admin.users.data');

    Route::get('admin/users', [ProfileController::class, 'index'])->name('admin.users');

    Route::get('admin/users/edit/{user}', [ProfileController::class, 'edit'])->name('admin.users.edit');

    Route::post('admin/users/update/{user}', [ProfileController::class, 'update'])->name('admin.users.update');

    Route::get('admin/users/edit/', [ProfileController::class, 'edit'])->name('admin.users.edit.url'); // SEULEMENT POUR L'URL

    Route::post('admin/users/create', [ProfileController::class, 'store'])->name('admin.users.create');

    Route::delete('admin/users/delete/', [ProfileController::class, 'destroy'])->name('admin.users.delete');

    Route::post('admin/users/resetPassword/{user}', [ProfileController::class, 'resetPassword'])->name('admin.users.resetPassword');

    Route::post('admin/users/resetImage/{user}', [ProfileController::class, 'resetImage'])->name('admin.users.resetImage');

    //EVENT
    Route::get('admin/events', [EventController::class, 'indexAdmin'])->name('admin.events');

    Route::post('admin/events/create', [EventController::class, 'store'])->name('admin.events.create');

    Route::delete('admin/events/{id}/delete', [EventController::class, 'destroy'])->name('admin.events.delete');

    Route::get('admin/events/edit/{id}', [EventController::class, 'edit'])->name('admin.events.edit');

    Route::post('admin/events/update/{id}', [EventController::class, 'update'])->name('admin.events.update');

    //ROUND
    Route::get('admin/events/rounds/edit/{id}', [RoundController::class, 'edit'])->name('admin.events.rounds.edit');

    Route::post('admin/events/rounds/create', [RoundController::class, 'store'])->name('admin.events.rounds.create');

    Route::post('admin/events/rounds/update/{id}', [RoundController::class, 'update'])->name('admin.events.rounds.update');

    Route::post('admin/events/rounds/{id}/add-team', [RoundController::class, 'addTeam'])->name('admin.events.rounds.addTeam');

    Route::delete('admin/events/rounds/{roundId}/remove-team/{teamId}', [RoundController::class, 'removeTeam'])->name('admin.events.rounds.removeTeam');

    Route::delete('admin/events/rounds/{id}/delete', [RoundController::class, 'destroy'])->name('admin.events.rounds.delete');

    //RESULTAT
    Route::get('admin/results', [ResultController::class, 'indexAdmin'])->name('admin.results');

    Route::post('admin/results/create', [ResultController::class, 'store'])->name('admin.results.create');

    Route::get('admin/results/get-rounds/{event}', [ResultController::class, 'getRounds'])->name('admin.results.getRounds');

    Route::get('admin/results/get-rounds/', [ResultController::class, 'getRounds'])->name('admin.results.getRounds.url'); //SEULEMENT POUR RECUP LE NOM DE LA ROUTE POUR AJAX, NE PAS UTILISER

    Route::get('admin/results/get-teams/{roundId}', [ResultController::class, 'getTeams'])->name('admin.results.getTeams');

    Route::get('admin/results/get-teams/', [ResultController::class, 'getTeams'])->name('admin.results.getTeams.url'); //SEULEMENT POUR RECUP LE NOM DE LA ROUTE POUR AJAX, NE PAS UTILISER

    Route::delete('admin/results/{id}/delete', [ResultController::class, 'destroy'])->name('admin.results.delete');

    //MEDAL
    Route::get('admin/medals', [MedalController::class, 'indexAdmin'])->name('admin.medals');

    Route::post('admin/medals/create', [MedalController::class, 'store'])->name('admin.medals.create');

    Route::delete('admin/medals/delete/{medal}', [MedalController::class, 'destroy'])->name('admin.medals.delete');
});

//USER CONNECTED
Route::middleware(['auth'])->group(function () {
    Route::get('account', [ProfileController::class, 'indexAccount'])->name('account');

    Route::put('account/updatePhoto', [ProfileController::class, 'updatePhoto'])->name('profile.updatePhoto');
});

//USER HAS TEAM
Route::middleware(['auth', 'checkTeam'])->group(function () {
    Route::get('myteam', [TeamController::class, 'indexMyTeam'])->name('myTeam');

    Route::put('myteam/updateLogo', [TeamController::class, 'updateLogo'])->name('team.updateLogo');

    Route::post('myteam/updateBio', [TeamController::class, 'updateBio'])->name('team.updateBio');

    Route::post('myteam/update', [TeamController::class, 'update'])->name('team.update');
});

////////////////PUBLIC
//INDEX
Route::get('/', [IndexController::class, 'index'])->name('index');

//NEWS
Route::get('news', [NewsController::class, 'index'])->name('news');

Route::get('news/{news}', [NewsController::class, 'show'])->name('news.show');

//PROFILE
Route::get('profile/{user}', [ProfileController::class, 'show'])->name('profile.show');

//TEAM
Route::get('teams', [TeamController::class, 'index'])->name('teams');

Route::get('teams/{team}', [TeamController::class, 'show'])->name('teams.show');

//EPREUVE
Route::get('events', [EventController::class, 'index'])->name('events');

Route::get('events/{event}', [EventController::class, 'show'])->name('events.show');

//ROUND
Route::get('rounds/{round}', [RoundController::class, 'show'])->name('rounds.show');

//RESULTAT
Route::get('results', [ResultController::class, 'index'])->name('results');

//CLASSEMENT
Route::get('rank', [RankController::class, 'index'])->name('rank');
