@extends('events.template')
@section('content')

<div style="max-width: 1000px;margin-left: auto;margin-right: auto;">
@foreach ($events as $event)
    <div>
    <h2>{{$event->name}}</h2>
    <ul style="list-style-type: square;">
        <li>Le {{$event->date}}</li>
        <li>Epreuve de : {{$event->sport}}</li>
        <li>X VS X clé secondaire???</li>
    </ul>
    </div>
@endforeach
</div>

@endsection