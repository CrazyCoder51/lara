@extends('template')
@section('title') Jeux de l'URCA - Mon équipe @endsection
@section('curseur-header')
    @php
        $curseur = "myTeam";
    @endphp
@endsection
@section('content')
    @auth

        @if (!empty(Auth::user()->team_id))
            @php
                $team = Auth::user()->team;
            @endphp

<div class="container mt-5">

    @if(session('error'))
        <div class="alert alert-danger mt-3" role="alert">
            {{ session('error') }}
        </div>
    @endif

    @if(session('success'))
        <div class="alert alert-success mt-3" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <div class="row justify-content-center">
        <div class="col-md-8">
            <a class="text-secondary mb-4" href="{{route('index')}}">🠔 Accueil</a>
            <div class="card">
                <div class="card-header bg-light text-dark">
                    <strong>Mon équipe : </strong>{{ $team->name }}<br>
                    <strong>Composante : </strong>{{ $team->composante }}
                </div>
                <div class="card-body text-center">
                    @if ($team->logo != NULL)
                        <img id="logoImg" class="img-fluid rounded-circle mb-3" alt="Logo Preview" src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }} Logo" class="img-fluid mb-3">
                    @else
                        <img id="logoImage" class="img-fluid rounded-circle mb-3" alt="Logo Preview" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" class="img-fluid mb-3">
                    @endif

                    <form method="POST" action="{{ route('team.update') }}" enctype="multipart/form-data" class="mb-4">
                        @csrf
                        @method('POST')

                        <div class="form-group">
                            <label for="logoInput">Changer le logo</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input @error('logoInput') is-invalid @enderror" id="logoInput" name="logoInput">
                                <label class="custom-file-label" for="logoInput">Choisir un fichier</label>
                                @error('logoInput')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                            </div>
                            
                        </div>

                        <div class="form-group">
                            <label for="bio">Biographie de l'équipe</label>
                            <textarea id="bio" class="form-control @error('bio') is-invalid @enderror" name="bio" rows="4">{{ $team->bio }}</textarea>
                            @error('bio')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Mettre à jour</button>
                    </form>

                    <hr>

                    <a style="background-color: #717171; border-color: #717171;color: white;" class="btn btn-primary btn-block" href="{{route('teams.show',['team' => $team->id])}}">Voir le profil de mon equipe</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Fonction pour mettre à jour et redimensionner l'image en coupant au centre
    function updateLogoImage(input) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var img = new Image();

            img.onload = function () {
                // Créer un canvas pour redimensionner et couper l'image
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                // Les dimensions du canvas et de la zone à découper
                var canvasSize = 250;
                var cutSize = Math.min(img.width, img.height);

                // Redimensionner et couper au centre
                canvas.width = canvasSize;
                canvas.height = canvasSize;
                var offsetX = (img.width - cutSize) / 2;
                var offsetY = (img.height - cutSize) / 2;
                ctx.drawImage(img, offsetX, offsetY, cutSize, cutSize, 0, 0, canvasSize, canvasSize);

                // Mettre à jour l'attribut src de l'image avec l'image redimensionnée et coupée
                document.getElementById('logoImg').src = canvas.toDataURL('image/png');
            };

            // Charger l'image dans l'élément img
            img.src = e.target.result;
        };

        // Lire les données de l'image sélectionnée
        reader.readAsDataURL(input.files[0]);
    }

    // Ajouter un écouteur d'événements pour détecter le changement du champ de fichier
    document.getElementById('logoInput').addEventListener('change', function () {
        var fileName = this.files[0].name; // Obtenez le nom du fichier sélectionné

        // Mettez à jour le libellé du champ de fichier avec le nom du fichier
        var label = document.querySelector('.custom-file-label');
        label.textContent = fileName;

        updateLogoImage(this);
    });
</script>
            
            
            
        @endif
    @endauth
@endsection