<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\Team;
use App\Models\Result;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::orderBy('date', 'desc')->get();
        return view('events.index', compact('events'));
    }

    public function indexAdmin()
    {
        $events = Event::all();
        $teams = Team::all();

        return view('admin.events', compact('events', 'teams'));
    }

    public function create()
    {
        return view('events.create');
    }

    public function store(Request $request)
    {
        // Validation des données
        $request->validate([
            'name' => 'required|string',
            'date' => 'required|date',
            'sport' => 'required|string',
        ]);

        // Création d'un nouvel événement
        Event::create($request->all());

        return redirect()->back()->with('success', 'Événement créé avec succès.');
    }

    public function show($id)
    {
        $event = Event::findOrFail($id);

        $medals = $event->medals->sortBy(function ($medal) {
            switch ($medal->type) {
                case 'gold':
                    return 1;
                case 'silver':
                    return 2;
                case 'bronze':
                    return 3;
                default:
                    return 4;
            }
        });

        $eventResults = Result::with(['team'])
            ->whereHas('round', function ($query) use ($event) {
                $query->where('event_id', $event->id);
            })
            ->select('team_id', DB::raw('SUM(points) as total_points'))
            ->groupBy('team_id')
            ->orderByDesc('total_points')
            ->get();

        return view('events.show', compact('event','eventResults','medals'));
    }

    public function edit($id)
    {
        $event = Event::findOrFail($id);
        $teams = Team::all();

        return view('admin.events.edit', compact('event','teams'));
    }

    public function update(Request $request, $id)
    {
        try {
            // validation données
            $request->validate([
                'name' => 'nullable|string',
                'date' => 'nullable|date',
                'sport' => 'nullable|string',
            ]);

            if (!$request->filled('name') && !$request->filled('date') && !$request->filled('sport')) {
                return redirect()->back()->with('error', 'Veuillez remplir au moins l\'un des champs.');
            }

            $event = Event::findOrFail($id);

            //tableau de donnees
            $data = [];

            if ($request->filled('name')) {
                $data['name'] = $request->input('name');
            }

            if ($request->filled('sport')) {
                $data['sport'] = $request->input('sport');
            }

            if ($request->filled('date')) {
                $data['date'] = $request->input('date');
            }

            $event->update($data);

            return redirect()->back()->with('success', 'Événement mis à jour avec succès.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Une erreur est survenue');
        }
    }

    public function destroy($id)
    {
        //épreuve a supprimer
        $event = Event::findOrFail($id);

        // Detachez les equipes des rounds
        foreach ($event->rounds as $round) {
            $round->teams()->detach();
        }

        // Supprimez manches de l'épreuve
        $event->rounds()->delete();

        // Supprimez épreuve
        $event->delete();

        return redirect()->back()->with('success', 'Épreuve supprimée avec succès');
    }
}