<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Round;

class RoundSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Utiliser la factory pour créer 5 manchjes
        Round::factory(20)->create();
    }
}
