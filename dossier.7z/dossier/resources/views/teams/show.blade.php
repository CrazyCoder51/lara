@extends('template')
@section('title') Jeux de l'URCA - Team : {{ $team->name }} @endsection
@section('curseur-header')
    @php
        $curseur = 3;
    @endphp
@endsection

@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Équipe</h2>
    <a class="text-secondary mb-4" href="{{route('teams')}}">🠔 Liste des équipes</a>
    <div class="card mb-4">
        <div class="card-header">
            <h2 class="mb-0">{{ $team->name }}</h2>
        </div>
        <div class="card-body">
            <div class="text-center">
                @if (!empty($team->logo))
                    <img src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }}" class="img-fluid mb-3 rounded-circle" style="max-width: 150px;">
                @else
                    <img src="{{ asset('storage/teams/default.png') }}" alt="Image par défaut" class="img-fluid mb-3 rounded-circle" style="max-width: 150px;">
                @endif
                @if (!empty($team->composante))
                    <p class="text-muted mb-0"><strong>Composante :</strong> {{$team->composante}}</p>
                @endif
                <p class="text-muted"><strong>Total de points :</strong> {{$totalPoints}}</p>
            
                @if (!empty($team->bio))
                    <div class="my-4">
                        <h4 class="mb-3">Biographie de l'équipe</h4>
                        <p class="lead">{{ $team->bio }}</p>
                    </div>
                @else
                    <p class="text-muted">Aucune description disponible pour cette équipe.</p>
                @endif
            </div>
                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="d-flex flex-column align-items-center">
                            <i class="fas fa-medal fa-3x" style="color: gold;"></i>
                            <p class="mt-2"><strong>{{ $team->medals->where('type', 'gold')->count() }}</strong></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex flex-column align-items-center">
                            <i class="fas fa-medal fa-3x" style="color: silver;"></i>
                            <p class="mt-2"><strong>{{ $team->medals->where('type', 'silver')->count() }}</strong></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex flex-column align-items-center">
                            <i class="fas fa-medal fa-3x" style="color: #cd7f32;"></i>
                            <p class="mt-2"><strong>{{ $team->medals->where('type', 'bronze')->count() }}</strong></p>
                        </div>
                    </div>
                </div>

            <div class="mt-3">
                <h4>Membres de l'équipe</h4>
                <ul class="list-group">
                    @if(!($team->users->isEmpty()))
                        @foreach($team->users as $user)
                            <li class=" p-0 list-group-item">
                                <a href="{{ route('profile.show', ['user' => $user->id]) }}" class="d-block w-100 p-3">
                                    <div class="d-flex align-items-center">
                                        @if (!empty($user->avatar))
                                            <img src="{{ asset('storage/avatars/' . $user->avatar) }}" alt="{{ $user->name }}" class="img-fluid rounded-circle mr-3" style="max-width: 50px;">
                                        @else
                                            <img src="{{ asset('storage/avatars/default.png') }}" alt="Image par défaut" class="img-fluid rounded-circle mr-3" style="max-width: 50px;">
                                        @endif
                                        <h5 class="mb-0">{{ $user->name }}</h5>
                                    </div>
                                </a>
                            </li>
                        @endforeach
                    @else
                        <li class="list-group-item"><h5 class="mb-0">Aucun membre dans cette équipe.</h5></li>
                    @endif
                </ul>
            </div>

            <div class="mt-3">
                <h4>Médailles de l'équipe</h4>
                <ul class="list-group">
                    @if (!($team->medals->isEmpty()))
                        @foreach ($team->medals as $medal)
                            <li class="p-0 list-group-item">
                                <div class="d-flex align-items-center">
                                    <a href="{{ route('events.show', ['event' => $medal->event->id]) }}" class="d-block w-100 p-3">
                                        @if($medal->type == "gold")
                                            <i class="fas fa-medal" style="color: gold;"></i> Or
                                        @elseif($medal->type == "silver")
                                            <i class="fas fa-medal" style="color: silver;"></i> Argent
                                        @elseif($medal->type == "bronze")
                                        <i class="fas fa-medal" style="color: #cd7f32;"></i> Bronze
                                        @endif
                                        dans {{ $medal->event->name }}
                                    </a>
                                </div>
                            </li>
                        @endforeach
                    @else
                        <li class="list-group-item">Aucune médaille pour cette équipe.</li>
                    @endif
                </ul>
            </div>

            <div class="mt-3">
                <h4>Historique des matches de l'equipe</h4>


                <ul class="list-group">
                    @forelse($rounds as $round)
                        @if ($round->teams->isNotEmpty())
                            <li class="list-group-item p-0">
                                <a href="{{ route('rounds.show', ['round' => $round->id]) }}" class="d-block w-100 p-3">
                                    <div class="d-flex align-items-center">
                                        <p class="mb-0 text-center">
                                            <strong>{{ $round->event->name }}</strong> :
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                            @foreach ($round->teams as $team)
                                                @php
                                                    $teamResult = $round->results()->where('team_id', $team->id)->first();
                                                    $teamScore = $teamResult ? $teamResult->score : null;
                                                    $maxScore = $round->results()->max('score');
                                                @endphp
                
                                                <span class="{{ $teamScore !== null && $teamScore == $maxScore ? 'text-success' : '' }}">
                                                    {{ $team->name }}
                
                                                    @if ($teamResult)
                                                        <span class="font-weight-bold">({{ $teamResult->score }})</span>
                                                    @endif
                                                </span>
                
                                                @if (!$loop->last) <span class="font-weight-bold">VS</span> @endif
                                            @endforeach
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                        </p>
                                    </div>
                                </a>
                            </li>
                            @endif
                        </li>
                    @empty
                        <li class="list-group-item">Aucune manche jouée pour le moment.</li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection