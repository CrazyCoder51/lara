@extends('template')
@section('title') Jeux de l'URCA - Manche @endsection
@section('curseur-header')
    @php
        $curseur = 4;
    @endphp
@endsection

@section('content')
<div class="container mt-5">
    <h2 class="mt-4">Détails de la manche</h2>
    <a class="text-secondary mb-4" href="{{ route('events.show', $round->event->id) }}">🠔 {{$round->event->name}}</a>
    <div class="card">
        <div class="card-header" style="position: relative; overflow: hidden;">
            <div class="img-background-event" style="background-image: url('{{ asset('storage/images/logo.png') }}');">
            </div>
            <h5 class="mb-0">
                    <li class="list-group-item">
                        <div class="d-flex align-items-center">
                            @if ($round->teams->isNotEmpty())
                                <p class="mb-0">
                                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"> <path d="m2.75 9.25 1.5 2.5 2 1.5m-4.5 0 1 1m1.5-2.5-1.5 1.5m3-1 8.5-8.5v-2h-2l-8.5 8.5"/> <path d="m10.25 12.25-2.25-2.25m2-2 2.25 2.25m1-1-1.5 2.5-2 1.5m4.5 0-1 1m-1.5-2.5 1.5 1.5m-7.25-5.25-4.25-4.25v-2h2l4.25 4.25"/> </svg> 
                                    @foreach ($round->teams as $team)
                                        @php
                                            $teamResult = $round->results()->where('team_id', $team->id)->first();
                                            $teamScore = $teamResult ? $teamResult->score : null;
                                            $maxScore = $round->results()->max('score');
                                        @endphp

                                        <span class="{{ $teamScore !== null && $teamScore == $maxScore ? 'text-success' : '' }}">
                                            {{ $team->name }}

                                            @if ($teamResult)
                                                <span class="font-weight-bold">({{ $teamResult->score }})</span>
                                            @endif
                                        </span>

                                        @if (!$loop->last) <span class="font-weight-bold">VS</span> @endif
                                    @endforeach
                                </p>
                                @else
                                    <p class="mb-0">Manche vide<small> #{{$round->id}}</small></p>
                                @endif
                        </div>
                    </li>
                </h5>
        </div>

        <div class="card-body">
            <strong>Épreuve: </strong><a href="{{ route('events.show', $round->event->id) }}">{{ $round->event->name }}</a><br>
            <strong>Heure: </strong>{{ \Carbon\Carbon::parse($round->hour)->isoFormat('H[h]mm') }}<br><br>

            <h4>Liste des équipes participantes</h4>
            <ul class="list-group">
                @if ($round->teams->isNotEmpty())
                    @foreach ($round->teams as $team)
                    <li class="list-group-item p-0">
                        <a href="{{ route('teams.show', ['team' => $team->id]) }}" class="d-block w-100 p-3">
                            <div class="d-flex align-items-center">
                                @if ($team->logo)
                                    <img class="rounded-circle" src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }} Logo" width="25" style="margin-right: 8px;">
                                @else
                                    <img class="rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                @endif
                                <h5 class="mb-0">
                                    {{$team->name}}
                                </h5>
                            </div>
                        </a>
                    </li>
                    @endforeach
                @else
                    <li class="list-group-item p-0">
                        <div class="d-block w-100 p-3 d-flex align-items-center">
                            <h5 class="mb-0">
                                Aucun participant pour cette manche.
                            </5>
                        </div>
                    </li>
                @endif
            </ul>
            <br>

            <h4>Tableau des scores de la manche</h4>
            @if ($teams->isNotEmpty())
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Team</th>
                                <th>Score total de la manche</th>
                                <th>Points remporté pour l'épreuve</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($teams as $team)
                                <tr>
                                    <td><a href="{{ route('teams.show', ['team' => $team->id]) }}">
                                            @if ($team->logo)
                                                <img class="rounded-circle" src="{{ asset('storage/teams/' . $team->logo) }}" alt="{{ $team->name }} Logo" width="25" style="margin-right: 8px;">
                                            @else
                                                <img class="rounded-circle" src="{{ asset('storage/teams/default.png') }}" alt="Default Team Logo" width="25" style="margin-right: 8px;">
                                            @endif
                                            {{ $team->name }}
                                        </a>
                                    </td>
                                    <td>{{ $team->total_score }}</td>
                                    <td>{{ $team->total_points }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @else
            <ul class="list-group">
                <li class="list-group-item p-0">
                    <div class="d-block w-100 p-3 d-flex align-items-center">
                        Aucun score pour cette manche.
                    </div>
                </li>  
            </ul>
            @endif  
        </div>
    </div>
</div>
@endsection