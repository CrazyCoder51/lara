/* Bouton header responsive*/
const toggleButton = document.getElementById('toggleButton');
const backgroundButton = document.getElementById('backgroundButton');
const naviList = document.getElementById('navi-list');

toggleButton.addEventListener('click', () => {
    naviList.classList.toggle('active-menu');
    backgroundButton.classList.toggle('active-menu');
})

backgroundButton.addEventListener('click', () => {
    naviList.classList.toggle('active-menu');
    backgroundButton.classList.toggle('active-menu');
})